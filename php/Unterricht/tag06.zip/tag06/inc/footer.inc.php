</main>
<footer class="row">
	<div class="col-md-6 bg-primary bg-opacity-55 text-light">&copy; by design</div>
	<div class="col-md-6 bg-primary bg-opacity-25">TERMS AND CONDITIONS</div>
</footer>
</div>
</body>
</html> 
