<!DOCTYPE html>
<html lang="de">
<head>
	<meta charset="utf-8" />
	<title>Projekt <?php pageTitle();?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link  rel="stylesheet" href="../bootstrap/css/bootstrap.css" />
	<link  rel="stylesheet" href="css/styles.css" />
</head>
<body class="bg-secondary">
<div class="container bg-light">
<header class="row" id="header">
<div class="col-12 bg-primary bg-opacity-75 text-light">
	<h1 class="display-2 text-center">design follows PHP</h1>
</div>
<div class="col-12 bg-dark">
	<nav class="navbar navbar-expand navbar-dark">
		<ul class="navbar-nav">
			<li class="nav-item">
				<a href="index.php" class="nav-link <?php echo empty($page) ? 'active fw-bold' : ''; ?>">Home</a>   
			</li>
			<li class="nav-item">
				<a href="index.php?page=about" class="nav-link <?= ($page === 'about') ? 'active fw-bold' : ''; ?>">About</a>
			</li>
			<li class="nav-item">
				<a href="index.php?page=entries" class="nav-link <?= ($page === 'entries') ? 'active fw-bold' : ''; ?>">Gästebuch</a>
			</li>
      <li class="nav-item">
				<a href="index.php?page=kontakt" class="nav-link <?= ($page === 'kontakt') ? 'active fw-bold' : ''; ?>">Kontakt</a>
			</li>
		</ul>
	</nav>
</div>
<!--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->
<!--wenn ein user nicht angemeldet ist dann das zeigen
die Variablen $_SESSION['id'] und $_SESSION['login'] kommen von der Datei
auth/user/login.php-->
<?php if( !isset($_SESSION['id']) && !isset($_SESSION['login']) ):?>
<div class="row border-top m-0 p-2" style="background: var(--bs-gray-300);">
<div class="col-md-5">
	<form action="auth/user/login.php" method="POST" class="bg-primary bg-opacity-25">
		<div class="input-group">
			<input type="text" class="form-control m-2" name="mail" placeholder="E-Mail..." />
			<input type="password" class="form-control m-2" name="pwd" placeholder="Password..." />
			<input type="hidden" class="form-control m-2" name="csrf_token" value="<?= csrf_token();?>" />
			<button type="submit" class="btn btn-primary m-2">Login</button>
		</div>
	</form>
</div>
<div class="col-12 my-2"><a href="?page=register" class="badge bg-dark p-2">Registrierung</a></div>
</div>
<?php else:?>
<div class="col-12 p-2">
<!--wenn ein user angemeldet ist dann das zeigen
die Variable $_SESSION['vorname'] kommt von der Datei
auth/user/login.php-->
<h3>Hallo <?= $_SESSION['vorname']?></h3>
<ul class="nav">
	<li class="nav-item m-1 btn btn-primary btn-sm">
		<a href="index.php?page=profil" class="nav-link  text-light">Mein Profil</a>
	</li>
	<li class="nav-item m-1 btn btn-danger btn-sm">
		<a href="auth/user/logout.php" class="nav-link  text-light">Logout</a>
	</li>
</ul>
</div>
<?php endif;?>
<!--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->
</header>
<main class="row">
<?php if(isset($_SESSION['msg'])):?>
<div class="col-12 p-2">
	<p class="alert alert-primary"><?= $_SESSION['msg']?></p>
</div>
<?php endif;?>