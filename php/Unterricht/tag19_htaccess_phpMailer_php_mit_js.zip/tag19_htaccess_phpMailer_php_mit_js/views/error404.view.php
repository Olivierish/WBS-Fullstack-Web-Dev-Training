<div class="card p-0 blau">
  <h2 class="card-header">Aufruf der Datei</h2>
  <div class="card-body">
    <p>Datei wurde leider nicht gefunden!</p>
  </div>
</div>