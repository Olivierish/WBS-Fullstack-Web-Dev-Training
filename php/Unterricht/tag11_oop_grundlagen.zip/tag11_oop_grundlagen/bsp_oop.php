<?php

#--------------------------------------------------------------

$konto1 = [
	'iban' => 'DE123456789',
	'name' => 'Max Mustermann', 
	'guthaben' => 800
];

$konto2 = [
	'iban' => 'DE787878785',
	'name' => 'Hilde Boss',
	'guthaben' => 1300
];
$konto3 = [
	'iban' => 'DE987987987',
	'name' => 'Tom Jerry',
	'guthaben' => 350
];

$konto4 = [
	'iban' => 'DE656565658',
	'name' => 'Anna Gold',
	'guthaben' => 3300
];


function kontoAusgabe($userKonto) {
	echo "Kontoinhaber: {$userKonto['name']} <br />
			  IBAN: {$userKonto['iban']} <br />
			  Der Kontostand ist: {$userKonto['guthaben']} <br />
			   ++++++++++++++++++++++++++++++++++++++++++++<br />";
}
#kontoAusgabe([]); #weil er nach guthaben und Name sucht

kontoAusgabe($konto1);
kontoAusgabe($konto2);
kontoAusgabe($konto3);
kontoAusgabe($konto4);
#--------------------------------------------------------------
/*
function transfer($from, $to, $amount) {
	if($from['guthaben'] > $amount) {
		$from['guthaben'] = $from['guthaben'] - $amount;
		$to['guthaben'] = $to['guthaben'] + $amount;
	}
	echo '<br />xxxx<br />';
	print_r($from);
	echo '<br />xxxx<br />';
	print_r($to);
	echo '<br />xxxx<br />';
	#Änderungen finden innerhalb der Funktion statt
	#außerhalb sind die nicht sichtbar
}

transfer($konto1, $konto2, 200);
echo '<br />';
#das alte Konto wird angezeigt
kontoAusgabe($konto2);
echo '<br />';
#das alte Konto wird angezeigt
kontoAusgabe($konto1);
*/
#--------------------------------------------------------------
function transfer(&$from, &$to, $amount) {
	if($from['guthaben'] > $amount) {
		$from['guthaben'] = $from['guthaben'] - $amount;
		$to['guthaben'] = $to['guthaben'] + $amount;
	}
	echo '<br />xxxx<br />';
	print_r($from);
	echo '<br />xxxx<br />';
	print_r($to);
	echo '<br />xxxx<br />';
	#Änderungen finden innerhalb und außerhalb der Funktion statt
	#weil & vor dem Parameter steht
}

transfer($konto1, $konto2, 200);
echo '<br />';
#das alte Konto wird aktualisiert
kontoAusgabe($konto1);
echo '<br />';
#das alte Konto wird aktualisiert
kontoAusgabe($konto2);
echo '<br />';
#kontoAusgabe([]);
#--------------------------------------------------------------
###############################################################
echo "<h2>Referenzen</h2>";
#der Inhalt von wert2 soll sich mit ändern, wenn der Inhalt von wert1 sich ändert
$wert1 = 22;
echo '<br />wert1 (beginn)+++++<br />';
echo $wert1;

#$wert2 = $wert1;
$wert2 = &$wert1; #wichtig ist &
echo '<br />wert2 = wert1 +++++<br />';
echo $wert2;

echo '<br />wert2 (wert1 wurde geändert)<br />';
$wert1 = 356;
echo $wert2;

echo '<br />wert1 neuer Inhalt<br />';
echo $wert1;
#--------------------------------------------------------------
###############################################################
#Objektorientierung - Klassen
/*
Warum OOP?
- Code besser strukturieren
- Code modularer machen
	Dadurch auch bei großen Projekten den Überblick behalten
- Komplexe Anwendungen in PHP entwickeln	
----------------------------------------
eine Funktion steht nicht nur für sich sondern gebündelt mit vielen anderen Funktionen

z.B. ein Bankkonto 
-hat verschiedenen Eigenschaften
	IBAN
	aktueller Kontostand
	KontoInhaber
	Dispo? wenn ja wie viel?
	Transaktionensliste
-hat Methoden
	Überweisung, wenn ausreichend Kontostand
*/
echo "<h2>Klassen</h2>";

/*
-eine Klasse anlegen
	Eigenschaften und Methoden definieren
	(Kochrezept für Eintopf)
	
-von dieser Klasse eine Instanz erstellen
 (hier wird das Kochrezept angewendet, um einen einzelnen Eintopf zu erstellen)
-Mit einem Kochrezept können wir ähnliche Eintöpfe kochen
*/

#nicht vorgeschrieben aber der Name beginnt mit einem Großbuchstaben

class BankKonto {
	public $iban;
	public $guthaben;
}

#eine Instanz oder Objekt von BankKonto erstellen
$user1 = new BankKonto();
var_dump($user1);
echo '<br />';
$user2 = new BankKonto();
var_dump($user2);
echo '<br />';

#die Eigenschaften aufrufen und was drin schreiben
$user1->iban = 'DE123456789';
$user1->guthaben = 1000;
var_dump($user1);

echo '<br />';
#wenn es eine Eigenschaft nicht gibt dann wird die erstellt
#nicht best practice, sollte man nicht verwenden
#nur Eigenschaften verwenden, die auch existieren
#$user2->xyz = 'Hallo';
#var_dump($user2);