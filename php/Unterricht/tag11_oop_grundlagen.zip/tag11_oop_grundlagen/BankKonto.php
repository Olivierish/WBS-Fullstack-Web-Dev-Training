<?php
/*
class BankKonto { 
	public $iban;
	public $guthaben;
	
	function ausgabeGuthaben() {
		#echo 'Kontostand ist....';
		#var_dump($iban); #geht nicht, weiss nicht, woher die Variable kommt
		
		#soll innerhalb der Klasse nach einer Variable iban suchen
		#var_dump($this->iban);
		
		echo "Der Kontostand von {$this->iban} ist : {$this->guthaben}";
	}
}
#geht nicht
#darf nur benutzt werden, wenn vorher eine Instanz der Klasse erstellt wurde
#ausgabeGuthaben();

$konto1 = new BankKonto();
$konto1->iban = 'DE123456789';
$konto1->guthaben = 1000;
$konto1->ausgabeGuthaben();
*/
#####################################################
#constructor - Konstruktor
/*
class BankKonto {
	public $iban;
	public $guthaben;
	
	#wird ausgeführt, wenn ein neues Objekt erstellt wird
	function __construct() {
		echo 'wird sofort aufgerufen';
	}
	
	function ausgabeGuthaben() {
		echo "Der Kontostand von {$this->iban} ist : {$this->guthaben}";
	}
}

$konto1 = new BankKonto();
echo '<br />';
#vorher wird Konstruktor ausgeführt
$konto1->iban = 'DE123456789';
$konto1->guthaben = 1000;
var_dump($konto1);
###########################################################
class BankKonto {
	public $iban;
	public $guthaben;
	
	function __construct($parameter1, $parameter2) {
		var_dump($parameter1, $parameter2);
	}
	
	function ausgabeGuthaben() {
		echo "Der Kontostand von {$this->iban} ist : {$this->guthaben}";
	}
}
#geht nicht weil 2 Parameter erwartet werden
$konto1 = new BankKonto();
#geht sofort in Konstruktor und ruft den auf
$konto1 = new BankKonto('DE123456789', 1000);
echo '<br />';
#die Werte werden nicht in ausgabeGuthaben() angezeigt
#weil die Variablen iban und guthaben jetzt keinen Wert haben (noch)
$konto1->ausgabeGuthaben();
echo '<br />';
var_dump($konto1);

###########################################################
class BankKonto {
	public $iban;
	public $guthaben;
	
	function __construct($parameter1, $parameter2) {
		$this->iban = $parameter1;
		$this->guthaben = $parameter2;
	}
	
	function ausgabeGuthaben() {
		echo "Der Kontostand von {$this->iban} ist : {$this->guthaben}";
	}
}
#Vorteil von einem Konstuktor ist
#wir können essentielle Werte entgegen nehmen
$konto1 = new BankKonto('DE123456789', 1000);
echo '<br />';
$konto1->ausgabeGuthaben();
echo '<br />';
var_dump($konto1);
echo '<br />++++++++<br />';
$konto2 = new BankKonto('NL123456789', 2000);
echo '<br />';
$konto2->ausgabeGuthaben();
echo '<br />';
var_dump($konto2);
###########################################################

class BankKonto {
	public string $iban;
	public float $guthaben;
	
	function __construct(string $parameter1, float $parameter2) {
		$this->iban = $parameter1;
		$this->guthaben = $parameter2;
	}
	
	function ausgabeGuthaben() {
		echo "Der Kontostand von {$this->iban} ist : {$this->guthaben}";
	}
}

$konto1 = new BankKonto('DE123456789', 1000);
$konto1->ausgabeGuthaben();
echo '<br />++++++++<br />';
$konto2 = new BankKonto('NL123456789', 2000);
$konto2->ausgabeGuthaben();
echo '<br />++++++++<br />';
#geht nicht weil
#der 1.Parameter kann er in string umwandeln
#den 2.Parameter kann er in float umwandeln geht nicht
$konto3 = new BankKonto(2000, 'NL123456789');
$konto3->ausgabeGuthaben();

###########################################################

#die kurzSchreibweise von oben
class BankKonto {
	public string $iban;
	public float $guthaben;
	
	function __construct(string $iban, float $guthaben) {
		#  Eigenschaft = Variable
		#best practice Variable und die Eigenschaft haben den gleichen Namen
		$this->iban = $iban;
		$this->guthaben = $guthaben;
	}
	
	#geht erst ab php 8
	#public - gleichzeitig Eigenschaft und Variable
	#function __construct(public string $iban, public float $guthaben) {}
	
	function ausgabeGuthaben() {
		echo "Der Kontostand von {$this->iban} ist : {$this->guthaben}";
	}
}

$konto1 = new BankKonto('DE123456789', 1000);
$konto1->ausgabeGuthaben();
echo '<br />++++++++<br />';
$konto2 = new BankKonto('NL123456789', 2000);
$konto2->ausgabeGuthaben();

###########################################################

*/

/*
class BankKonto {
	public string $iban;
	public float $guthaben;
	
	function __construct(string $iban, float $guthaben) {
		$this->iban = $iban;
		$this->guthaben = $guthaben;
	}
	
	function ausgabeGuthaben() {
		echo "Der Kontostand von {$this->iban} ist : {$this->guthaben}";
	}
	
	function transfer(BankKonto $to, float $amount) {
		if($this->guthaben < $amount) {
			echo "Die Überweisung von {$amount}€ geht nicht<br />Nicht ausreichend Guthaben vorhanden";
			return;
		}
		
		echo "Überweisung von {$this->iban} auf {$to->iban}: {$amount}€";
		$this->guthaben-= $amount;
		$to->guthaben+= $amount;
	}
}

$konto1 = new BankKonto('DE123456789', 1000);
$konto1->ausgabeGuthaben();
echo '<br />++++++++<br />';
$konto2 = new BankKonto('NL123456789', 2000);
$konto2->ausgabeGuthaben();
echo '<br />++++++++<br />';
$konto1->transfer($konto2, 200);
echo '<br />++++++++<br />';
$konto1->ausgabeGuthaben();
echo '<br />++++++++<br />';
$konto2->ausgabeGuthaben();
*/
###########################################################
echo '<h2>Sichtbarkeit</h2>';
/*
#schreibend auf die Eigenschaft zugreifen
#$konto1->guthaben = 200;
#$konto1->ausgabeGuthaben();

#das kann zu problemen führen
#z.B. wenn der Wert nicht negativ sein darf
$konto1->guthaben = -200;
var_dump($konto1->guthaben);
echo '<br />++++++++<br />';
$konto1->ausgabeGuthaben();
*/


#jedes mal, wenn Konto geändert wird, soll der neue Wert in die Datenbank geschrieben werden
#von außen einfach so die Daten ändern darf nicht passieren

#die Eigenschaft privat machen
#von außen darf nicht mehr zugegriffen werden
#nur innerhalb der Klasse darf geändert werden
/*
class BankKonto {
	private string $iban;
	private float $guthaben;
	
	function __construct(string $iban, float $guthaben) {
		$this->iban = $iban;
		$this->guthaben = $guthaben;
	}
	
	function ausgabeGuthaben() {
		echo "Der Kontostand von {$this->iban} ist : {$this->guthaben}";
	}
	
	function transfer(BankKonto $to, float $amount) {
		if($this->guthaben < $amount) {
			echo "Die Überweisung von {$amount}€ geht nicht\nNicht ausreichend Guthaben vorhanden";
			return;
		}
		
		echo "Überweisung von {$this->iban} auf {$to->iban}: {$amount}€";
		$this->guthaben-= $amount;
		$to->guthaben+= $amount;
	}
	#++++++++++++++++++++++++DatenKapselung+++++++++++++++++++++++++++
	#um auf die iban zuzugreifen
	#eine Methode erstellen
	function getIban() {
		return $this->iban;
	}
	
	function getGuthaben() {
		return $this->guthaben;
	}
	
	#Werte ändern - dafür auch Methoden erstellen
	function setIban($wert) {
		$this->iban = $wert;
	}
	
	function setGuthaben($wert) {
		$this->guthaben = $wert;
	}
}

$konto1 = new BankKonto('DE123456789', 1000);
$konto2 = new BankKonto('NL123456789', 2000);

#geht nicht weil private deklariert
#$konto1->guthaben = 200;
#$konto1->iban ='DE45454545';
#var_dump($konto1->guthaben);

#das geht 
#var_dump($konto1);

#var_dump($konto1->getIban());

var_dump($konto1);
*/
###########################################################
class BankKonto {
	private string $iban;
	private float $guthaben;
	
	#defaultwert ist public
	#ist besser, wenn auch immer davor steht public oder private oder...
	public function __construct(string $iban, float $guthaben) {
		$this->setIban($iban);
		$this->setGuthaben($guthaben);
	}
	
	private function ausgabeGuthaben() {
		echo "Der Kontostand von " . $this->getIban() . " ist : " . $this->getGuthaben();
	}
	
	public function transfer(BankKonto $to, float $amount) {
		if($this->getGuthaben() < $amount) {
			echo "Die Überweisung von {$amount}€ geht nicht\nNicht ausreichend Guthaben vorhanden";
			return;
		}
		
		echo "Überweisung von " . $this->getIban() . " auf " . $to->getIban() . ": {$amount}€";
		$this->guthaben -= $amount;
		$to->guthaben += $amount;
		
		echo '<br />';
		$this->ausgabeGuthaben();
		echo '<br />';
		$to->ausgabeGuthaben();
	}
	
	public function getIban() {
		return $this->iban;
	}
	
	public function getGuthaben() {
		return $this->guthaben;
	}

	public function setIban($wert) {
		$this->iban = $wert;
	}
	
	public function setGuthaben($wert) {
		$this->guthaben = $wert;
	}
	
	public function atmEinzahlung($amount) {
		$this->guthaben += $amount;
		$this->ausgabeGuthaben();
	}
}
/*
$konto1 = new BankKonto('DE123456789', 1000);
$konto2 = new BankKonto('NL123456789', 2000);

#geht nicht weil private
#$konto1->ausgabeGuthaben();

var_dump($konto1);
echo '<br />';
$konto1->setGuthaben(3000);
var_dump($konto1);
echo '<br />';
$konto1->atmEinzahlung(200);
echo '<br />';
var_dump($konto1);
echo '<br />Überweisung durchführen<br />';
$konto1->transfer($konto2, 100);
echo '<br />';
*/
###########################################################
$konto1 = new BankKonto('DE123456789', 1000);
$konto2 = new BankKonto('NL123456789', 2000);
echo '<p>Konto1 zahlt an Konto2</p>';
$konto1->transfer($konto2, 100);
echo '<p>Konto1 macht eine Einzahlung (auf eigenes Konto)</p>';
$konto1->atmEinzahlung(200);
###########################################################
###########################################################