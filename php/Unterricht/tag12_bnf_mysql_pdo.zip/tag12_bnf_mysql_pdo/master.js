"use strict";

//let cardHeaders = document.getElementsByClassName("card-header");
let cardHeaders = document.querySelectorAll(".card-header");

for(let wert of cardHeaders) {
  let cardBody = wert.nextElementSibling;
  cardBody.classList.add("d-none");
  wert.style.cursor = "pointer";

  //wert.addEventListener("click", function(){});
  wert.addEventListener("click", () => {
    cardBody.classList.toggle("d-none");
  });//ende addEventListener
}//ende for


/*
<h2 class="card-header" style="cursor: pointer;"><?= $result['nachname'] ?></h2>
<div class="card-body d-none"></div>
*/