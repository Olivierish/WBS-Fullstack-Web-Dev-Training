<!DOCTYPE html>
<html lang="de">
<head>
	<meta charset="utf-8" />
	<title>PHP - Projekt</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link  rel="stylesheet" href="../bootstrap/css/bootstrap.css" />
	<script src="master.js" async></script>
</head>
<body class="bg-secondary">
<div class="container bg-light">
<header class="row">
<div class="col-12 bg-primary bg-opacity-75 text-light">
	<h1 class="display-2">PHP -  MYSQL</h1>
</div>
</header>
<main class="row p-2">
<div class="col-md-12"> 
<?php
#PHP Data Objects
#PDO::prepare() - Bereitet eine Anweisung zur Ausführung vor und liefert ein Anweisungsobjekt
#PDOStatement::execute() - Führt ein Prepared Statement aus

#$db = new PDO('mysql:host=localhost;dbname=db_php_web02','root','');
#$stmt = $db->prepare('SELECT * FROM users');

#wenn eine SQL-Abfrage durchgeführt wird, erhalten wir als Rückgabewert der Methode
# PDO#query ein neues Objekt, das als Klasse PDOStatement hat
#Es repräsentiert das Ergebnis der SQL-Anweisung
# Man kann es verwenden, um die Ergebnisdaten auszulesen und weiterzuverarbeiten

#PDOStatement enthält nicht das Ergebnis sondern repräsentiert es nur
#deswegen wird nur das Original-SQL dort angezeigt
#Das Objekt hat nicht die Datensätze vorrätig, es weiß aber, wie es an diese herankommt.
#Das Objekt kann man danach jederzeit nach dem Ergebnis fragen und die Datensätze werden geliefert.
#var_dump($stmt);
#$stmt->execute();

#PDOStatement#fetchAll() = Alle Daten anzeigen
#PDOStatement#fetch() = NUR einen bestimmten Datensatz anzeigen
#Liefert das Ergebnis des SELECT in Form eines mehrdimensionalen Arrays
#index (Nummer der Position) und assoziativ array (über die Namen der Spalten)
#$result = $stmt->fetchAll();

#$stmt = $db->prepare('SELECT * FROM users WHERE id = 1');
#$stmt->execute();
#$result = $stmt->fetchAll();
?>
<pre><?php #var_dump($result);?></pre>
<!--#####################################################################-->
<h2>PDO-Attribute</h2>
<?php
#Die Datenbank-Verbindung (PDO-Objekt) kann verschiedene Attribute haben

#+++++++++++++++++Fehlverhalten einstellen+++++++++++++++++++++++++++++++
#PDO::ATTR_ERRMODE
#PDO::ATTR_ERRMODE => PDO::ERRMODE_SILENT (standardfall -PDO reicht keine Fehlermeldung von MySQL weiter)
#PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING (ist das aktiv, wird eine Warnung angezeigt, wenn MySQL einen Fehler meldet)
#PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION (ist das aktiv, wird das Skript sofort mit einem PHP-Fehler abgebrochen)
/*
$optionen = [
	PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING
];
$db = new PDO('mysql:host=localhost;dbname=db_php_web02','root','', $optionen);

$stmt = $db->prepare('SELECT * FROM users WHERE idw = 1');
$stmt->execute();
$result = $stmt->fetch();
*/
?>
<pre><?php #var_dump($result);?></pre>
<pre><?php #var_dump($db->errorInfo());?></pre>

<?php
#+++++++++++++++++Fetch-Modus einstellen++++++++++++++++++++++++++++++
#PDO::ATTR_DEFAULT_FETCH_MODE
#PDO::FETCH_BOTH (Default-Einstellung = Jede Spalte wird im ErgebnisArray mit numerischen Index als auch mit ihrem Namen angezeigt)
#PDO::FETCH_NUM (Ergebnis nur mit numerischen Index zurückgeliefert)
#PDO::FETCH_ASSOC (Ergebnis nur mit assoziativen Array zurückgeliefert - ein sinnvoller Standard als Empfehlung)
/*
$optionen = [
	PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
];
$db = new PDO('mysql:host=localhost;dbname=db_php_web02','root','', $optionen);

$stmt = $db->prepare('SELECT * FROM users WHERE id = 1');
$stmt->execute();
$result = $stmt->fetch();
*/
?>
<pre><?php #var_dump($result);?></pre>
<pre><?php #var_dump($db->errorInfo());?></pre>

<?php
#+++++++++++++++++Vorschlag für eine Standard-PDO-Verbindung++++++++++++++++++++++++
/*
$optionen = [
	PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, #nur zur Entwicklung
	PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
];
$db = new PDO('mysql:host=localhost;dbname=db_php_web02','root','', $optionen);

#Unicode-Daten aus MySQL auslesen
#Wenn UTF-8 für eine Tabelle aktiv ist, ist leider noch nicht ausreichend.
#MySQL explizit mitteilen, dass eine Datenbankverbindung UTF-8 verwenden soll
#Über die SQL-Anweisung SET NAMES können wir MySQL mitteilen, dass alle Eingaben von nun an in dem gewünschten Zeichensatz kommen
#und auch der Server alle Daten in diesem Zeichensatz ausliefern soll.
$db->query('SET NAMES utf8');
#ab diesem Aufruf von PDO#query() werden alle Daten von MySQL als UTF-8 interpretiert (sollte als Standard-Datenbankverbindung sein)


$stmt = $db->prepare('SELECT * FROM users');
$stmt->execute();
$results = $stmt->fetchAll();
*/
#hinter PDO::FETCH_ASSOC oder PDO::FETCH_NUM oder PDO::FETCH_BOTH steckt eine Zahl
#var_dump(PDO::FETCH_ASSOC); #2
#var_dump(PDO::FETCH_NUM); #3
#var_dump(PDO::FETCH_BOTH); #4
#$results = $stmt->fetchAll(2);
#$results = $stmt->fetchAll(3);
#$results = $stmt->fetchAll(4);

#bei einer Zahl weiß man nicht, was dahinter steckt
#bei einer Konstante kann man das besser sehen bzw. lesen
?>
<pre><?php #var_dump($results);?></pre>
<pre><?php #var_dump($db->errorInfo());?></pre>

<ul class="list-group">
<?php #foreach($results AS $result):?>
<li class="list-group-item"><?php # strtoupper($result['nachname'])?></li>
<?php #endforeach;?>
</ul>
<?php
#+++++++++++++++++Fehler bei der Datenbank-Verbindung abfangen++++++++++++++++++++++++
#wenn Fehler auftaucht bei der Verbindung zur DB dann werden viele Infos angezeigt 
#Usrername, passwort usw...das muß verhindert werden
#Fehler ehisst - DB-Name falsch geschrieben oder Username falsch
$optionen = [
	PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, 
	PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
];
try {
	$db = new PDO('mysql:host=localhost;dbname=db_php_web02','root','', $optionen);
}
catch(PDOException $e) {
	#in $e steht die Fehlermeldung (kann man ausgeben, siehe unten)
	#var_dump($e->getMessage());
	echo 'Datenbankverbindung fehlgeschlagen';
	die();
}
$db->query('SET NAMES utf8');
/*
$stmt = $db->prepare('SELECT * FROM `users` WHERE `id`=3 ');
$stmt->execute();
#$results = $stmt->fetchAll();
$result = $stmt->fetch();
*/
#brauchen keine Schleife weil nur ein Datensatz geliefert wird
?>
<!--
<ul class="list-group">
	<li class="list-group-item"><?php  #echo strtoupper($result['nachname'].' '.$result['vorname'])?></li>
	<li class="list-group-item"><?php  #echo $result['email']?></li>
</ul>
-->
<h2>Alle Daten anzeigen (erstmal nur die Namen)</h2>
<?php
$stmt = $db->prepare('SELECT * FROM `users`');
$stmt->execute();
$results = $stmt->fetchAll();
?>

<ul class="list-group list-group-item-dark">
<?php foreach($results AS $result):?>
	<li class="list-group-item">
		<?php echo strtoupper($result['nachname'])?>
		<a href="index.php?id=<?=$result['id']?>" class="btn btn-sm btn-outline-primary">Detailansicht</a>
	</li>
<?php endforeach;?>
</ul>
<div class="row">
<?php
if(isset($_GET['id'])):
	#echo $_GET['id'];
	
	#nicht sicher
	#wenn in Adresszeile steht
	#index.php?id=hallo 
	#dann wird erzeugt 'SELECT * FROM `users` WHERE `id` = hallo'
	#denkt vergleich den Wert der Spalte id mit der Spalte hallo
	
	#wenn index.php?id=id  dann vergleicht er Spalte id mit der Spalte id
	#wenn fetchAll() noch steht dann werden alle Daten angezeigt
	#xxxxxxxxxxxxxxxxx
	#$stmt = $db->prepare('SELECT * FROM `users` WHERE `id` = '.$_GET['id']);
	#xxxxxxxxxxxxxxxxx
	####################################################################################
	#++++++++++++++++++++++++++++Prepared Statement+++++++++++++++++++++++++++++++++++++
	#xxxxxxxxxxxxxxxxx
	#Die Klasse PDOStatement - Platzhalter verwenden
	#Repräsentiert ein Prepared Statement und, nachdem es ausgeführt wurde, die zugehörige Ergebnismenge. 
	#PDOStatement::bindValue — Bindet einen Wert an einen Parameter
	#PDOStatement::bindParam() - Bindet einen Parameter an den angegebenen Variablennamen
	$stmt = $db->prepare('SELECT * FROM `users` WHERE `id` = :nummer ');
	#$stmt->bindValue(':nummer', $_GET['id']);
	#PDO::PARAM_INT - explizit angeben, dass der Wert eine Zahl ist
	#PDO::PARAM_STR - explizit angeben, dass der Wert ein String ist
	#$stmt->bindValue(':nummer', $_GET['id'],PDO::PARAM_INT);
	
	#hier zeigt er immernoch den Datensatz mit id = 1
	#$_GET['id'] = 1;
	#$stmt->bindValue(':nummer', $_GET['id']);
	#$_GET['id'] = 2;
	
	#hier zeigt er den Datensatz mit id = 2 (Referenz)
	#$_GET['id'] = 1;
	#$stmt->bindParam(':nummer', $_GET['id']);
	#$_GET['id'] = 2;
	
	#if($_GET['id'] < 1) $_GET['id'] = 1;
	$stmt->bindValue(':nummer', $_GET['id']);
	$stmt->execute();
	$result = $stmt->fetch();
	
	#echo '<pre>'.var_dump($result).'</pre>';
	?>
<?php if($result !== false):?>
	<ul class="list-group list-group-item-success my-2">
	<?php if($result['motto'] !== NULL):?>
		<li class="list-group-item bg-danger text-light text-center"><?php echo strtoupper($result['motto'])?></li>
	<?php endif;?>
		<li class="list-group-item">
			<?php echo strtoupper($result['nachname'] . ', ' . $result['vorname'])?>
		</li>
		<li class="list-group-item">E-Mail:<?php echo $result['email']?></li>
	</ul>
	<?php endif;?>
<?php endif;?>
</div>
<?php
/*
Daten filtern
SELECT * FROM users
SELECT nachname FROM `users`
SELECT `nachname` FROM `users`
SELECT * FROM `users` WHERE `id` = 2 
*/
?>
</div>
<!--####################################################################################-->
<h2>Alle Daten anzeigen</h2>
<?php foreach($results AS $result):?>
	<div class="card list-group-item-dark p-0 my-2">
		<h2 class="card-header">
			<?php echo strtoupper($result['nachname'])?>
		</h2>
		<div class="card-body">
			<p>
				<?php echo strtoupper($result['nachname'] . ', ' . $result['vorname'])?>
			</p>
			<p>E-Mail:<?php echo $result['email']?></p>
		</div>
	</div>
<?php endforeach;?>
<!--####################################################################################-->
</main>

</div>
</body>
</html>
<?php
/*
Warum Datenbanken?
In vielen Anwendungen passiert exakt das Gleiche:

- CRUD
	Create - 	Neue Daten erstellen
	Read - 		Bestehende Daten auslesen
	Update - 	Bestehende Daten ändern
	Delete - 	Bestehende Daten löschen
	
- Zusatlich
	Daten filtern, sortieren, gruppieren usw.
	Daten müssen konsistent gehalten werden
	Gleichzeitige Schreibvorgänge verhindern
	Gleichzeitige Updates vermeiden
	
- Daten in einzelnen Dateien speichern, wäre sehr aufwendig (ohne Datenbanken)
--------------------------------------------
Datenbankmodelle
Die Struktur entsteht durch die Organisation der Daten mit Hilfe eines Datenbankmodells.

Es gibt verschiedene sogenannte Datenbankmodelle, die sich in der Praxis etabliert haben. 
Die bekanntesten sind:

➤ Netzwerkmodell
➤ hierarchisches Modell
➤ relationales Modell
➤ objektorientiertes Modell
➤ dokumentenorientiertes Modell
--------------------------------------------
Das Datenbankmodell bestimmt die Struktur zur Ablage der Daten und legt fest, wie Verbindungen
zwischen den Daten repräsentiert werden. 
Beispielsweise folgt das hierarchische Modell einer Baumstruktur.

Wollten Sie z. B. Unternehmen repräsentieren, könnten Sie auf der obersten Ebene die Unternehmen angeben und darunter (als Äste) deren Abteilungen 
(Vertrieb, Service, Einkauf, usw). 
Diese wiederum untergliedern sich in mehrere Mitarbeiter. 
Abteilungsübergreifend arbeitende Mitarbeiter lassen sich so nur schwer darstellen.

Eine Datenbank (DB) ist eine Sammlung von Daten, denen ein Datenbankmodell zugrundeliegt.
Ein Datenbank-Management-System (DBMS) ist ein Programm, das die Daten bzw. Datenbanken verwaltet.

Im Sprachgebrauch wird häufig der Begriff Datenbank gebraucht, obwohl eigentlich ein DBMS gemeint ist. 
Ich werde aber, um Verwechslungen zu vermeiden, die beiden Begriffe immer in ihrer korrekten Bedeutung verwenden.
------------------------------------------------------
Welches Datenbanksystem?

Es gibt verschiedene Datenbanken
- MySQL / MariaDB
- PostgreSQL
- MongoDB
------------------------------------------------------
Das relationale Model dagegen verwendet (vereinfacht ausgedrückt) 
Tabellen zur Datenorganisation.
Das Unternehmensbeispiel könnten Sie mit Hilfe der Tabellen 
unternehmen, abteilungen und mitarbeiter realisieren.

Das relationale ist das mit Abstand meistverbreitete Datenbankmodell.
#############################################
BNF
BNF steht für Backus-Naur-Form, nach den Namen der beiden Entwickler. 
(John Backus und Peter Naur)

Es handelt sich dabei um eine sogenannte Metasprache, mit der sich andere Sprachen, wie z.B. Programmiersprachen beschreiben und definieren lassen.

Heute ist die BNF (in notationellen Varianten) die Standardbeschreibungstechnik für Programmiersprachen.

 Zeichen, die Sie direkt angeben, nennt die BNF Terminale. Das bedeutet, sie sind »zu Ende«, im Sinne von »sie werden nicht weiter ersetzt«.
 
 Die Platzhalter, die Sie später ersetzen, nennt die BNF dementsprechend Nichtterminale oder Variablen. 
 Zur Unterscheidung setzen Sie einfach Groß- und Kleinschreibung ein. 
 Terminale schreiben Sie groß, Nichtterminale dagegen klein.

ICH WERDE DICH DEN gefrässige_tierart ZUM FRAß VORWERFEN

ZU MEINEM GEBURTSTAG WÜNSCHE ICH MIR EIN farbe fahrzeugtyp.

Diese Variablen können Sie z.B. mit rotes Fahrrad oder blaues Auto ausprägen.
-----------------------------
BNF
-----
Konzept 					Darstellung
-----------------------------
Terminale 				Wort in Großbuchstaben
-----------------------------
Nichtterminale 		(Variablen) Wort in Kleinbuchstaben
xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
SQL
-----
Zweck 										BNF
------------------------------------------------------
Datenbank anlegen 				CREATE DATABASE db_name
------------------------------------------------------
Datenbank löschen 				DROP DATABASE db_name
------------------------------------------------------
Datenbanken auflisten 		SHOW DATABASES
------------------------------------------------------
Symbole in der BNF, die sich weiter ersetzen lassen, heißen…

Nichtterminale
Variablen
xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
Gegeben ist folgender BNF-Ausdruck:

zahl + zahl = summe

Finden Sie korrekte Ausprägungen:

✔4 + 4 = 8
✔5 + 6 = 12
✔5 + 6 = 11
+ 56 = 11
11 = 5 + 6
#############################################
#############################################
#############################################
#############################################
#############################################
#############################################
*/
?>