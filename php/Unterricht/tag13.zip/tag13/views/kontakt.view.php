<div class="card">
  <h2 class="card-header">Kontakt</h2>
  <div class="card-body">
    <p>so können Sie uns erreichen</p> 
  </div>
</div>