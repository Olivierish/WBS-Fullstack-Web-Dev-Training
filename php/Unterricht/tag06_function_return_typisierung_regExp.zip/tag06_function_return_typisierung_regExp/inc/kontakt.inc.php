<h2>Reguläre Ausdrücke</h2> 

<form action="index.php?page=kontakt" method="POST" class="bg-primary col-md-6 bg-opacity-10 rounded-2 p-3">
	<div class="my-1">
		<input type="text" name="vorname" 
						placeholder="Vorname eingeben" 
							class="form-control"
							value="<?= $_POST['vorname'] ?? '' ; ?>" />
	</div>
	
	<div class="my-1">
		<input type="text" name="nachname" 
						placeholder="Nachname eingeben" 
							class="form-control"
							value="<?= $_POST['nachname'] ?? '' ; ?>"  />
	</div>

  <div class="my-1">
	  <input type="text" name="mail" 
					placeholder="E-Mail eingeben" 
						class="form-control"
						value="<?= $_POST['mail'] ?? '' ; ?>"  />
  </div>
	
	<div class="my-1">
	  <input type="text" name="city" 
					placeholder="Wohnort eingeben" 
						class="form-control"
						value="<?= $_POST['city'] ?? '' ; ?>"  />
  </div>
	<div class="my-1">
	  <input type="text" name="plz" 
					placeholder="PLZ eingeben" 
						class="form-control"
						value="<?= $_POST['plz'] ?? '' ; ?>"  />
  </div>
	
	<div>
		<input type="submit" value="senden" class="btn btn-success" name="btn" />
		<input type="reset" value="löschen" class="btn btn-danger" id="delete"  />
	</div>
</form>
<div class="row">
<div class="alert alert-success my-4">
<?php
/*
RegExp => Reguläre Ausdrücke
		
\ => Alt Gr + ?
		
\s 	= white-space: Leerzeichen, Tabulator, Zeilenumbruch
\S 	= kein Leerzeichen (no space - Alles außer \s) 
.			Ein beliebiges Zeichen außer Zeilenumbruch
\d	= eine Ziffer (0-9)
\D	= ein Zeichen, das keine Ziffer ist
\w	= ein alphanummerisches Zeichen [a-zA-Z_0-9]
\W	= ein nicht alphanummerisches Zeichen [^a-zA-Z_0-9] (Alles außer \w)
		
+++++++++++++++++++++++++++++++++++++++++
Multiplikatoren
exakte Anzahl an Vorkommen
x{m,n}	= x soll mind. m-mal, aber nicht mehr als n-mal vorkommen
x{n,}		= x soll mind. n-mal vorkommen
x{n}		= x soll genau n-mal vorkommen

+++++++++++++++++++++++++++++++++++++++++
Quantifizierer 
x*			= x soll 0-mal oder öfter vorkommen ( alternative x{0,} )
x+			= x soll 1-mal oder öfter vorkommen ( alternative x{1,} )
x?			= x soll 0 oder 1 mal vorkommen ( alternative x{0,1} )
		
/				= Begrenzer
^				= Zirkumflex (Anfang einer Zeichenkette)
$ 			= Ende eines Musters
		
[^0-9] => innerhalb von [] => Negation (hier...keine Ziffer)

+++++++++++++++++++++++++++++++++++++++++
Modifikatoren
i = kein Unterschied zwischen Groß- und Kleinschreibung
g = globale Suche

+++++++++++++++++++++++++++++++++++++++++
preg_match — Führt eine Suche mit einem regulären Ausdruck durch

preg_match(
    string $pattern,
    string $subject,
    array &$matches = null,
    int $flags = 0,
    int $offset = 0
): int|false

pattern
    Der Ausdruck, nach dem gesucht werden soll, als Zeichenkette.
subject
    Die zu durchsuchende Zeichenkette.
matches
    Falls der Parameter matches angegeben wurde, wird er mit den Suchergebnissen gefüllt. $matches[0] enthält dann den Text, der auf das komplette Suchmuster passt, $matches[1] den Text, der auf das erste eingeklammerte Teilsuchmuster passt und so weiter.
flags
    flags kann eine Kombination der folgenden Flags sein: 
*/
if(isset($_POST['btn'])) {

$zeichen = "/^[a-zA-ZäöüÄÖÜß\-\s\.]{2,10}$/";
$mail = "/^.+@.+$/";							
$ort = "/^(paris|berlin|münchen)$/i";
$plz = "/^[0-9]{5}$/";

if( empty($_POST['vorname'])) {
	echo '<p>Vorname darf nicht leer sein</p>';
}
else if( !preg_match($zeichen, $_POST['vorname']) ) {
	echo '<p>Vorname darf NUR Buchstaben haben (min.2, max. 10 Zeichen)</p>';
}
else if( !preg_match($zeichen, $_POST['nachname']) ) {
	echo '<p>Nachname darf NUR Buchstaben haben (min.2, max. 10 Zeichen)</p>';
}
else if( !preg_match($mail, $_POST['mail']) ) {
	echo '<p>Muster für E-Mail: test@test.de</p>';
}
else if( !preg_match($ort, $_POST['city']) ) {
	echo '<p>NUR Berlin oder Paris oder München sind erlaubt</p>';
}
else if( !preg_match($plz, $_POST['plz']) ) {
	echo '<p>PLZ: Nur 5 stellige Zahl erlaubt</p>';
}
else {
	#wenn alles ok dann Ausgabe
	$name = $_POST['nachname'];
	$vorname = $_POST['vorname'];
	$email = $_POST['mail'];
	$city = $_POST['city'];
	$postcode = $_POST['plz'];

	echo '<div>';
	echo '<p>Hallo '.$name.' '.$vorname.'</p>';
	echo '<p>Wohnort:<br /> '.$postcode.' '.$city.'</p>';
	echo '<p>E-Mail '.$email.'</p>';
	echo '</div>';
}

}#ende isset
?>
<script>

document.getElementById("delete").addEventListener("click", () => {
	//beim klick auf löschen wird die Seite neu geladen
	//dadurch werden alle Daten entfernt
	window.location.href = window.location.href;
});

</script>
</div>
</div>