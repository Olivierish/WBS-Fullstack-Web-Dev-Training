<h2>Funktionen sind wichtig</h2>   

<?php

function gruss($value) {
  echo $value;
}

gruss('Max');
echo '<br />';
gruss('Tom');
echo '<br />';
gruss('Jerry');

/*
Hallo MAX
Guten Morgen max
Guten Abend Max
*/
?>

<h2>Funktion mit Rückgabewert</h2>
<?php
function ausgabe($value) {
  return $value;
}

echo ausgabe('Anna');

echo '<br />';
$a = ausgabe('MiCHelle');

echo $a;
echo '<br />';
echo strtoupper($a);
echo '<br />';
echo strtolower($a);
echo '<br />';
echo ausgabe('Tracy');
?>

<h2>Gültigkeitsbereich von Variablen</h2>
<?php
#globale Variable
$foo = 'Hugo';

echo '<br />';

function daten() {
  $fara = 'Jerry'; #lokale Variable
  echo $fara;

  #das SchlüsselWort global schreiben
  #global $foo;
  #echo $foo;
}

#echo $fara;
echo '<br />';
daten();

echo '<br />';
echo $foo;
?>

<h2>Konstanten</h2>
<?php

#define('PFAD','images/');
const PFAD = 'images/';

echo PFAD;

?>
<h2>Typisierung</h2>
<?php
function greeting(string $name, int $age, string $city) {
  #       Anna (25) aus Paris
  return $name . ' (' . $age . ') aus ' . $city; 
}

echo greeting('Anna','25','Paris');
#########################################
function rechner(int $a, int $b) {
  return $a + $b;
}

echo '<br />';

echo rechner(3, 4);
#########################################
echo '<br />';
function rechner2(int $a, int $b):int {
  return ($a + $b);
  #return 'Addition: ' . ($a + $b);
}

echo rechner2(5, 10);
?>