<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="utf-8" />
  <title>PHP - Grundlagen</title>
</head>
<body>
<?php 

#Dies ist ein Kommentar

//Variablen

/*
Mehrzeiliger
Kommentar

$a;
echo $a; #Fehler - hat keinen Wert
*/

$a = 2;
echo $a;

echo "<br />";
#PHP liest die Datei von oben nach unten
#Variablen kann man überschreiben
$a = "Guten Morgen";
echo $a;

echo "<br />";
#in '' sieht alles als String und wird nicht geparst
echo '$a hat den Wert: $a';

echo "<br />";
#hier erkennt er in "" die Variable
echo "$a hat den Wert: $a";

echo "<br />";

echo '$a hat den Wert: ' . $a;

echo "<br />";
#kann man auch so schreiben
echo '$a hat den Wert: ' . "$a";
echo "<br />";
#Variable kann in einer anderen Variable stehen
$d = "Variable a in d: ". $a;
echo $d;

echo "<br />";
#++++++++++++++++++++++++++++++++++++++++++++++++++++++
#escaping
#echo "Ich bin "30" jahre alt"; #Fehler weil " "" "
echo "Ich bin \"30\" jahre alt";

echo "<br />";
#unten werden die Variablen nicht geparst und alles als Strings dargestellt
echo 'Ich bin \'30\' jahre alt';

#VariablenNamen sind case-sensetive
#zwischen Groß und Klein wird unterschieden
#echo $A;
/*
validNamen

$wert:
$Wert;
$_WERT;
$_123;
$wert1;
---------------------
invalidNamen

$123;
$:wert;
$?;

++++++++++++++++++++++++++
#Konventionen bei der Benennung von Variablen
#aussagekräftige Namen

#camelCase -> kleinGroßKleinGroß (mit klein anfangen)

#PascalCase -> GroßKleinGroßKlein (auch der 1.Buchstaben Groß)

#snake_case -> wert_wert_wert (mit Unterstrich, alles klein)

#kebab-case -> wert-wert-wert (mit Bindestrich, alles klein)

#UPPERCASE -> WERT_WERT (mit Unterstrich, alles GROß)
*/
#++++++++++++++++++++++++++++++++++++++++++++++++++++++
echo "<h2>Referenzen</h2>";
#der Inhalt von wert2 soll sich mit ändern, wenn der Inhalt von wert1 sich ändert
$wert1 = 22;

echo $wert1;

echo '<br />';
#$wert2 = $wert1;
$wert2 = &$wert1; #wichtig ist &
echo $wert2;

echo '<br />';
$wert1 = 356;
echo $wert2;

echo '<br />';
echo $wert1;
#++++++++++++++++++++++++++++++++++++++++++++++++++++++
echo "<h2>Datentypen</h2>";

echo "<h3>Zahlen</h3>";

//Integer
#Ganzzahlen (Zahlen ohne kommastellen)
echo 23;

//Float
#Fließkommazahlen (Zahlen mit kommastellen)
echo "<br />". 23.123;

echo "<br />";

$zahl = 1720.298;
#$zahl = 1720.598;

//round() runden
echo "<h3>round()</h3>";
#bis 0.5 -> abgerundet
#ab 0.5 -> aufgerundet
echo round($zahl);
echo "<br />";
//2. Parameter(optional) - Nachkommastellen
echo round($zahl,1);

//floor() nächstKleinere Zahl
echo "<h3>floor()</h3>";
echo floor($zahl);

//ceil() nächstGrößere Zahl
echo "<h3>ceil()</h3>";
echo ceil($zahl);

echo "<h3>number_format()</h3>";
/*
number_format(
  $zahl, 
    2 (NachkommaStellen),
      "Zeichen vor den NachkommaStellen",
        "TausenderTrenneZeichen"
)
*/

echo number_format($zahl,2,",",".");

//rand() ZufallsZahl(nicht schnell)
echo "<h3>Zufallszahl</h3>";
echo rand(0,100);

#mt_rand() ZufallsZahl(schnell und noch zufälliger)
echo "<h3>Zufallszahl</h3>";
echo mt_rand(0,100);
#++++++++++++++++++++++++++++++++++++++++++++++++++++++
echo "<h2>weitere Datentypen</h2>";
//Strings
#Zeichenketten (Beliebiger Inhalt -> Zahlen, Buchstaben usw.)
echo "Hallo";

//Booleans
#Wahrheitswerte (true oder false)
#true bedeutet wahr (ein Wert oder Ergebnis ist wahr)
#false bedeutet nicht wahr (ein Wert oder Ergebnis ist nicht wahr)

//Arrays
#Nur kurz hier als Beispiel, werden wir ausführlich besprechen
#Ansammlung von Daten (wie ein Ordner bzw. Container)
$x = array(15, "Hugo", 12.123, $user=true, false, true);

#wenn der Inhalt ausgegeben werden soll dann in einer Schleife 
#echo $x;

echo "<br />";
#oder
var_dump($x);
#++++++++++++++++++++++++++++++++++++++++++++++++++++++
echo "<h2>Zeichenketten</h2>";
echo "<h3>Stringfunktionen</h3>";
#es gibt sehr viele Funktionen für Strings
#hier nur ein paar wichtigen vielleicht
#  pc        012345          
$zeichen1 = ' Guten Tag ';

echo "<h3>strlen - Die Länge eines Strings</h3>";
echo strlen($zeichen1);

echo "<h3>substr - Teil eines Strings</h3>";
# substr(string $string, int $offset, ?int $length = null): string

#fängt bei 0 an und gibt alles zurück
#echo substr($zeichen1, 0);

#fängt bei 0 an und gibt 2 Zeichen zurück (das 1. Zeichen ist Leerzeichen)
#echo substr($zeichen1, 0, 2);

#wenn negativ - fängt am Ende an und gibt 5 Zeichen zurück 
#echo substr($zeichen1, -2);

#wenn negativ - fängt am Ende an und gibt das 6 Zeichen zurück 
echo substr($zeichen1, -6, 1);

echo "<h3>explode() - String zerlegen bzw. teilen</h3>";

$zerlegen = explode(" ", $zeichen1);

#echo $zerlegen;

echo "<h3>Datentype ermitteln</h3>";
echo gettype($zerlegen);
echo '<br />';

var_dump($zerlegen);
#++++++++++++++++++++++++++++++++++++++++++++++++++++++
echo "<h3>trim() - Leerzeichen entfernen</h3>";

#' Guten Tag '
echo strlen( trim($zeichen1) );

echo "<h3>strrev() - String umkehren</h3>";
echo strrev($zeichen1);

echo "<h3>String in Großbuchstaben</h3>";
echo strtoupper($zeichen1);

echo "<h3>String in Kleinbuchstaben</h3>";
echo strtolower($zeichen1);

echo "<h3>Position des gesuchten Strings</h3>";
echo strpos($zeichen1, "G");

echo "<h3>strip_tags() - entfernt HTML und PHP Tags</h3>";
$zeichen2 = "<div>Design <b>follows</b> <em>function</em></div>";

#alle HTML-Elemente entfernen außer <br> und <b>
echo strip_tags($zeichen2, "<br><b>");

echo "<h3>strcmp() - 2 Strings miteinader vergleichen</h3>";
$zeichen3 = "Halloo";
$zeichen4 = "Hallooo";
#$zeichen4 = "hallo";
#echo strcmp($zeichen1, $zeichen2);
echo strcmp($zeichen3, $zeichen4);
/*
$zeichen3 = "Hallo";
$zeichen4 = "Hallo";

$zeichen3 = 2;
$zeichen4 = 3;

0 = beide gleich lang
1 = der 1. String ist länger bzw. größer
-1 = der 2. String ist länger bzw. größer
*/

echo "<h3>str_repeat() - String wiederholen</h3>";

echo str_repeat("+", 40);

echo '<br />';

echo str_repeat("Hallo PHP <br />", 10);
#++++++++++++++++++++++++++++++++++++++++++++++++++++++
echo "<h3>String und Addition</h3>";
#wird als Integer interpretiert
echo "6" + "22";

#echo " 6 " + " 22 "; kommt Fehlermeldung aber rechnet trotzdem
#++++++++++++++++++++++++++++++++++++++++++++++++++++++
echo "<h3>Addition</h3>";
echo 4 + 4;

echo "<h3>Subtraktion</h3>";
echo 4 - 4;

echo "<h3>Multiplikation</h3>";
echo 4 * 4;

echo "<h3>Division</h3>";
echo 16 / 4;

echo "<h3>Modulo</h3>";
echo 5 % 4; #Restwert

echo "<h3>Potenz</h3>";
echo 4 ** 3; # 4 * 4 * 4
#++++++++++++++++++++++++++++++++++++++++++++++++++++++
echo '<h3>if</h3>';
#ob bestimmte Bedingung erfüllt ist
/*
if(Bedingung) {
  Anweisungen;
}
*/
$number = 5;

if($number >= 6) {
  echo '$number ist >= 6';
} else {
  echo '$number ist < 6';
}
#++++++++++++++++++++++++++++++++++++++++++++++++++++++
echo '<h3>for - Schleife</h3>';
#wenn Zahl der Abläufe bekannt ist
/*
for(Initialisierung; Bedingung; Aktualisierung) {
  Anweisungen;
}
1 2 3 4 5...20
Zeile 1
Zeile 2
.... 
Zeile 20
*/
for($counter = 1; $counter <= 5; $counter++) {
  #echo $counter;
  echo "Zeile ".$counter."<br />";
}
#++++++++++++++++++++++++++++++++++++++++++++++++++++++
echo '<h3>while - Schleife</h3>';
//wird selten benutzt
$counter1 = 1;
while($counter1 <= 5) {
  echo 'Hallo while: ' . $counter1 . '<br />';
  $counter1++;
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++
echo '<h3>Zweisungsoperatoren += und -=</h3>';
$y = 4;
#rechne auf den aktuellen Wert von $x 3 hinzu
#$y += 3;
#echo $y;

#Alternative wäre
#echo $y + 3;
$y = $y + 3;
echo $y;
echo '<p>-----------------</p>';
$y -= 2;
#$y = $y - 3;
echo $y;
?>





</body>
</html>