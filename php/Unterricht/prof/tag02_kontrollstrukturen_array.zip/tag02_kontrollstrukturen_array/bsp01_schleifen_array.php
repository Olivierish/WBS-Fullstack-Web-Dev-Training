<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="utf-8" />
  <title>PHP - Grundlagen</title>
  <style>
    .ungerade { background: #efefef;}
    .gerade { background: #ffc;}
    .ausgabe {
      background: #ffc;
      margin: 10px;
      list-style: none;
      padding: 10px;
      width: 200px;
    }
  </style>
</head>
<body>
<?php
$benzin = 1.75;
$diesel = 1.80;
?>

<table>
<caption>Tankstelle - Preise</caption>
<thead>
  <tr>
    <th>Liter</th> <th>Benzin €</th> <th>Diesel €</th>
  </tr>
</thead>
<tbody>
<?php for($i = 1; $i <= 5; $i++):
  if($i % 2 === 0) {
    $zeile = "gerade";
  } else {
    $zeile = "ungerade";
  }
?>
  
  <tr class="<?= $zeile; ?>">
   <td><?= $i; ?></td>
   <td><?= number_format($benzin * $i,   2,  ","   , ".") ?></td>
   <td><?= number_format($diesel * $i,   2,  ","   , ".") ?></td> 
  </tr>
<?php endfor;?>
</tbody>
</table>

<?php

echo "<h2>Zeichenketten - Funktionen</h2>";
$zeichen1 = "tom";
$zeichen2 = "<h2>Robert</h2>";

echo "Hallo <b>". ucfirst($zeichen1) ."</b>";
echo '<br />';
echo "Hallo <b>". htmlspecialchars($zeichen2) ."</b>";
echo '<br />';
echo "Hallo <b>". htmlentities($zeichen2) ."</b>";
#-------------------------------------------------------
echo "<h2>Variablen prüfen und löschen</h2>";

$var1 = "Hallo Hugo";
#$var1 = "";

#PHP macht draus eine Zahl (Integer)
#in PHP bedeutet 0 immer leer
#$var1 = "0";

#null bedeutet NICHTS
#wäre so, als ob man $var1; schreibt (Variable ohne definition)
$var1 = null;

#echo $var1; #nichts
#var_dump($var1);

#echo isset($var1);
var_dump(isset($var1));

echo "<br />";
#empty() prüft, ob eine Varibale einen Inhalt hat
#echo empty($var1);
echo "<br />";
var_dump(empty($var1));
#-------------------------------------------------------
echo '<h2>if - empty()</h2>'; 
#ob die Variable nicht leer ist
$name = 'Max';
if($name == 'Max') {
  echo 'Hallo Max';
}
echo '<br />++++++<br />';
if(!empty($name)) {
  echo 'Hallo ' . $name;
}else {
  echo 'Hallo Namenloser';
}
#-------------------------------------------------------
echo "<h2>Eine Variable löschen</h2>";

$a = "Hallo";
#unset() löscht eine Variable
#unset($a);

echo $a; #Fehler wenn vorher unset()
#-------------------------------------------------------
echo "<h2>Vergleichsoperatoren</h2>";
#true = 1, false = no output
echo '<h4>equal compare</h4>';
#   int   float
echo 6 == 6.0; #true
echo '<p>-----------------</p>';
#   int   int
echo 6 == 6; #true
echo '<p>-----------------</p>';
#   int   string
echo 6 == '6'; #true

echo '<h4>identical compare (streng)</h4>';
echo 6 === 6.0; #false
echo '<p>-----------------</p>';
echo 6 === 6; #true
echo '<p>-----------------</p>';
echo 6 === '6'; #false
echo '<p>-----------------</p>';
echo 6 != 6.0;  #false
echo '<p>-----------------</p>';
echo 6 !== 6.0;  #true
/*
< , <=
>, >=
*/
#-------------------------------------------------------
echo "<h2>Logische Operatoren</h2>";
#wenn beide Wahrheitswerte wahr sind, wird true ergeben
var_dump(true && true);
echo "<br />";
var_dump(true && false);
echo "<br />";
var_dump(false && false);
echo "<br />++++++++++++++++++<br />";
#wenn einer den beiden Wahrheitswerte wahr ist, wird true ergeben
var_dump(true || true);
echo "<br />";
var_dump(true || false);
echo "<br />";
var_dump(false || false);
#-------------------------------------------------------
echo '<h2>Negation von Wahrheitswerten</h2>';
var_dump(true && !true); #false
echo '<p>-----------------</p>';
var_dump(true && !false); #true
echo '<p>-----------------</p>';
var_dump(!false && !false); #true
echo '<p>-----------------</p>';
var_dump(!true && !true); #false
#-------------------------------------------------------
echo "<h2>if - else - verschachteln</h2>";
$tnZahl = 10;

if($tnZahl < 5) {
  echo 'Es sind noch sehr viele Plätze frei';
}
else
{
  if($tnZahl < 8) {
    echo 'Es sind noch wenige Plätze frei';
  }
  else 
  {
        if($tnZahl < 10) {
          echo 'Es sind kaum Plätze frei';
        }
        else {
          echo 'Wir sind ausgebucht';
        }//ende else
  }//ende else
}//ende else
#-------------------------------------------------------
echo "<h2>if - else - if</h2>";
if($tnZahl < 5) {
  echo 'Es sind noch sehr viele Plätze frei';
}
else if($tnZahl < 8) {
  echo 'Es sind noch wenige Plätze frei';
}
else if($tnZahl < 10) {
  echo 'Es sind kaum Plätze frei';
}
else {
  echo 'Wir sind ausgebucht';
}
#-------------------------------------------------------
echo "<h2>switch</h2>";
#switch-Anweisung+++++++++++++++
/*
switch(Selektor) {
  case Wert: Anweisung; break;
  case Wert: Anweisung; break;
  default: Anweisung; break;
}
*/

$note = 5;

switch($note) {
  case 1 : echo "PHP ist super"; break;
  case 2 : echo "PHP ist gut"; break;
  case 3 : echo "PHP ist normal"; break;
  case 4 : echo "PHP ist durchscnitt"; break;
  case 5 : echo "PHP ist schlecht"; break;
  case 6 : echo "PHP ist keine gute Programmiersprache"; break;
  default: echo "PHP ist ok"; break;
}
#-------------------------------------------------------
echo "<h2>Array (Ansammlung von Feldern, Elementen)</h2>";
#indiziertes Array (Nummerisch)
#größere Mengen an Daten in Variablen zur späteren Verarbeitung zu speichern
$arr1 = array();
var_dump($arr1); #hier sind 0 Elemente vorhanden

echo '<br />++++++<br />';
#
$arr2 = array('Apfel', 'Banane', 20, 33.32, false);
var_dump($arr2);

echo '<br />++++++<br />';

$arr3 = array(
            'Apfel', 
            'Banane', 
            20, 
            33.32, 
            false,
            array('wert-1','wert-2','wert-3')
          );
var_dump($arr3);
#-------------------------------------------------------
echo "<h2>Array (kurzSchreibweise - short syntax)</h2>";
$arr4 = ['Merkel','Helene'];
var_dump($arr4);
echo '<br />++++++<br />';

#echo $arr4; 
#Fehler weil zu viele Daten (entweder einzeln ansprechen oder in einer Schleife)

echo $arr4[0];
echo $arr4[1];
#-------------------------------------------------------
#bei indizierten Ararys sind die Schlüssel fest
#das 1.Element, das 2.Element,...usw.
#assoziatives Array (die Schlüssel selber definieren)
echo '<h2>Array (Schlüssel beeinflüssen)</h2>';
$z = [
			  "1" => "Boss"
		];
var_dump($z);
#-------------------------------------------------------
echo "<h2>Assoziative Array</h2>";
# => Pfeiloperator
# Schlüssel => Wert
$arr5 = [
  'Name' => 'Boss',
  'Vorname' => 'Hugo',
  'Alter' => 30,
  'Wohnort' => 'Sylt'
];

echo $arr5['Name'] . ' '. $arr5['Vorname'] . ' ' .$arr5['Alter'] . 'j alt';;
#echo $arr5['name']; #zwischen Groß und Klein wird unterschieden
#-------------------------------------------------------
echo "<h2>Array ausgeben (indiziert)</h2>";
$arr6 = ['Apfel', 'Banane', 'Mango', 'Kiwi', 'Birne'];

echo "<ul>";
echo "<li>Obstsorten(".count($arr6).")</li>";

for($i = 0; $i < count($arr6); $i++):
  echo "<li>". ($i + 1) . " " .$arr6[$i]."</li>";
endfor;

echo "</ul>";
/*
<li>Apfel $arr6[0]</li> $i = 0
<li>Banane $arr6[1]</li> $i = 1
<li>Banane $arr6[2]</li> $i = 2
*/
#-------------------------------------------------------
echo "<h2>Array ausgeben mit foreach(indiziert)</h2>";
#foreach(welchesArray AS neueVariable)

echo "<ul>";
foreach($arr6 AS $element) {
  echo "<li>$element</li>";
}
echo "</ul>"; 
#-------------------------------------------------------
echo "<h2>Array Assoziativ verschachteln</h2>";
$arr7 = [
  [
    'Name'    => 'Merkel',
    'Vorname' => 'Angela',
    'Alter'   => 60,
    'Wohnort' => 'Berlin',
  ],
  [
    'Name'    => 'Fischer',
    'Vorname' => 'Helene',
    'Alter'   => 40,
    'Wohnort' => 'Mallorca',
  ]
];

echo "Anzahl der Teilnehmer: " . count($arr7);

#     0   1
# [  [], []  ]
#echo $arr7[1]["Name"];

for($i = 0; $i < count($arr7); $i++) {
  echo "<ul>";
    echo "<li>".$arr7[$i]['Name']."</li>";
    echo "<li>".$arr7[$i]['Vorname']."</li>";
  echo "</ul>";
}
#-------------------------------------------------------
echo "<h2>Array Assoziativ verschachteln (Ausgabe mit foreach)</h2>";
#das machen wir nächstes mal
foreach($arr7 AS $element) {
  echo "<ul class='ausgabe'>";
  foreach($element AS $key=>$value) {
      echo "<li>" .$key. " : " .$value. "</li>";
  }
  echo "</ul>";
}
?>




</body>
</html>
<!--
<tr class="ungerade">   <td>1</td> <td> 1 * 1.75</td>    </tr>   1 / 2
<tr class="gerade">     <td>2</td> <td> 2 * 1.75</td>    </tr>   2 / 2
<tr class="ungerade">   <td>3</td> <td> 3 * 1.75</td>     </tr>  3 / 2 
<tr class="gerade">     <td>4</td> <td> 4 * 1.75</td>    </tr>  4 / 2 
-->