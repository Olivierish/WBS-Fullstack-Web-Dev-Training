<div class="col-md-12 p-2">
  <form action="auth/user/insert.php" method="POST" class="rounded-1 p-2 bg-success bg-opacity-25">
    <div class="p-1">
      <input type="text" name="name" placeholder="Nachname..." class="form-control my-1" />
      <input type="text" name="vorname" placeholder="Vorname..." class="form-control my-1" />
      <input type="text" name="mail" placeholder="E-Mail..." class="form-control my-1" />
      <input type="text" name="pwd" placeholder="Passwort..." class="form-control my-1" />
      <input type="hidden" name="token" value="<?= bin2hex(random_bytes(64))?>" class="form-control my-1" />
    </div>
    <div class="my-1 text-center">
      <button type="submit" class="btn btn-lg btn-success fw-bold">mich anmelden</button>
      <button type="reset" class="btn btn-lg btn-danger fw-bold">löschen</button>
    </div>
  </form>
</div>

<?php 

#CSRF
#$pwd = '123456';

#$pwd = md5('123456789');


#var_dump($pwd);

/*
if( md5(UserEingabe) === passwort(in DB) ) {
  dann alles gut 
}
*/

#$pwd = sha1('123456');
#var_dump($pwd);

#rainbow-table 

#$pwd = password_hash('123456', PASSWORD_DEFAULT);
#var_dump($pwd);

#$userEingabe = '123456...';

#var_dump( password_verify($userEingabe, $pwd) );
#------------------------------------------------
#$start = microtime(true);
#$pwd = md5('123456');
#$ende = microtime(true);
#var_dump($ende - $start);
#float(3.0994415283203E-6)


#-----------------------------------------------
#$start = microtime(true);
#$pwd = password_hash('123456', PASSWORD_DEFAULT);
#$ende = microtime(true);
#var_dump($ende - $start);

?>