<?php

session_start();


/*
Was ist CSRF? 
Cross-Site Request Forgery (CSRF)-Angriffe sind häufig auftretende Schwachstellen in Webanwendungen, 
die das Vertrauen ausnutzen, das eine Website einem Benutzer und seinem Browser bereits entgegengebracht hat.

https://www.ionos.de/digitalguide/server/sicherheit/was-ist-cross-site-request-forgery/
*/

#kryptografisch sichere zufalligge bytes (Binär-form)
#var_dump( random_bytes(10) );

#bin2hex() - Wandelt Binär-Daten in ihre hexadezimale Entsprechung um
#var_dump( bin2hex(random_bytes(64)) );

$page = $_GET['page'] ?? '';

require_once __DIR__.'/inc/db_connect.php';

require_once __DIR__.'/inc/functions.php';

require_once __DIR__.'/inc/header.php';

#flush messages
#die Variable soll NUR 1 mal angezeigt werden und danach gelöscht
#Variable steht in header.php
if(isset($_SESSION['msg']))  unset($_SESSION['msg']);

$templateFile = __DIR__.'/views/' .$page. '.view.php';

if(file_exists($templateFile)) {
	require_once $templateFile;
}
else {
	require_once __DIR__.'/views/index.view.php';
}

require_once __DIR__.'/inc/footer.php';