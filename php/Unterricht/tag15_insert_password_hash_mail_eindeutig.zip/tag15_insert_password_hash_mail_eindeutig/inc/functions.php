<?php 

function e($value) {
  return htmlspecialchars($value, ENT_QUOTES, 'UTF-8', true);
}

function pageTitle() {
  global $page;
  switch($page) {
    case 'about':   echo ' - About'; break;
    case 'entries': echo ' - Gästebuch'; break;
    case 'kontakt': echo ' - Kontakt'; break;
    default: echo ' - Startseite'; break;
  }
}

function redirect($url) {
  header('Location:'.$url);
  exit();
}

function csrf_token() {
  $csrfToken = bin2hex(random_bytes(64));
  if( !isset($_SESSION['token']) || empty($_SESSION['token'])) {
    $_SESSION['token'] = $csrfToken;
  }
  return $_SESSION['token'];
}

/*
in DB steht das Format so: Jahr-Monat-Tag
angezeigt werden soll: Tag.Monat.Jahr

mann/frau kann auch DateTimeImmutable benutzen

siehe:
https://www.php.net/manual/de/class.datetime.php
*/
function formatiereDatum($dbDatum, $format = 'd.m.Y H:i') {
  $datum_db = new DateTime($dbDatum);
  return $datum_db->format($format);
}

#formatiereDatum('created_at')
#Jahr-Mon-Tag->format(Tag.Mon.Jahr);