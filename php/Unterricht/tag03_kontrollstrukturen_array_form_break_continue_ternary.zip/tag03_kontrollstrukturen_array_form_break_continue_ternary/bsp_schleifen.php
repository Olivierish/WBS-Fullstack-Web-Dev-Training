<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="utf-8" />
  <title>PHP - Grundlagen</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.css" />
</head>
<body class="bg-secondary">
<div class="container bg-light">
<h2>for-Schleife</h2>
<?php
#normalerweise, wenn Zahl der Abläufe bekannt ist
for($i = 1; $i <= 5; $i++) {
  echo $i . ' Wir sind im Auftrag des Herrn unterwegs<br />';
}
?>
<!--+++++++++++++++++++++++++++++++++++++++-->
<h2>while-Schleife</h2>
<?php
#normalerweise, wenn Zahl der Abläufe nicht bekannt ist (in Prog. kann man alles manipulieren)
#selten benutzt
$counter = 5;
while($counter < 5) {
  echo $counter . ' Wir sind im Auftrag des Herrn unterwegs<br />';
  $counter++;
}
?>
<h2>do-while-Schleife</h2>
<?php
#wie while
#Unterschied
#bei while wird zunächst geprüft dann der SchleifenKörper ausgeführt
#hier wird der SchleifenKörper immer einmal ausgeführt
#$counter2 = 5;
#sehr selten benutzt
$counter2 = 1;
do {
  echo $counter2 . ' Wir sind im Auftrag des Herrn unterwegs<br />';
  $counter2++;
}while($counter2 < 5);
?>
<!--+++++++++++++++++++++++++++++++++++++++-->
<h2>Tärnerer Operator</h2>
<?php
$number = 5;
#Bedingung ? tifftZu : trifftNichtZu;
#braucht 3 Operanden
#1 ? 2 : 3;
echo $number >= 6 ? '$number ist >= 6' : '$number <= 6';
/*
if($number >= 6) {
  echo '$number ist >= 6';
} else {
  echo '$number ist <= 6';
}
*/
?>
<!--+++++++++++++++++++++++++++++++++++++++-->
<h2>Spaceship Operator</h2>
<?php
#2 Werte werden verglichen
#wenn der 1.Wert größer ist dann 1 ausgegeben
#wenn der 2.Wert größer ist dann -1 ausgegeben
#wenn beide gleich sind dann 0 ausgegeben
echo 10 <=> 4;
echo '<br />++++++<br />';
echo 1 <=> 4;
echo '<br />++++++<br />';
echo 10 <=> 10;
echo '<br />++++++<br />';
#true wird als 1 gewertet in PHP und mehr wert
echo true <=> false;
echo '<br />++++++<br />';
#false wird als -1 gewertet in PHP und mit weniger wert
echo false <=> true;
echo '<br />++++++<br />';
#wenn beide gleich dann 0
echo true <=> true;
echo '<br />++++++<br />';
echo false <=> false;
echo '<br />++++++<br />';
#auch Strings kann man vergleichen
#bei String guckt, wo mehr Zeichen stehenund nach ASCII
echo 'hallo' <=> 'hallo';
echo '<br />++++++<br />';
echo 'hallo' <=> 'halloh';
echo '<br />++++++<br />';
#ASCII-Tabelle weil die Position von h=104 und von H = 72
echo 'Hallo' <=> 'hallo';
?>
<!--+++++++++++++++++++++++++++++++++++++++-->
<h2>Koaleszen-Operator</h2>
<?php 
#isset() abkürzen
#echo $username; #Fehler weil die Variable nicht da
#um das zu vermeiden, könnte man prüfen, ob die Variable existiert
if(isset($username)) {
  echo $username;
} else {
  echo 'Hallo';
}

echo '<br />+++++<br />';

#$username = 'Jerry';
echo $username ?? 'Guten Tag';
?>
<!--+++++++++++++++++++++++++++++++++++++++-->
<h2>break</h2>
<?php
#Abbruch
$counter3 = 1;
while($counter3 < 15) {
  echo 'Wir sind im Auftrag des Herrn unterwegs. '. $counter3++ .'<br />';
  #nach dem 1.Wert wird abgebrochen
  #break;
  #echo 'weiter';
  if($counter3 == 7) {
    break;
  }
}
echo 'Die Schleife wurde abgebrochen an Zeile ' . $counter3 .'<br />';
?>
<!--+++++++++++++++++++++++++++++++++++++++-->
<h2>continue</h2>
<?php
#Überspringen
//hier wird der 7. Schleifendurchlauf übersprüngen
//manchmal gibts vielleicht keinen 7 Stock oder 13. Stock:-)
for($i= 1; $i < 15; $i++) {
  if($i == 7 || $i == 13) {
    continue;
  }
  echo 'Wir sind im Auftrag des Herrn unterwegs. '. $i .'<br />';
}
?>
<!--+++++++++++++++++++++++++++++++++++++++-->
<h2>continue -  von vorne anfangen</h2>
<?php
$counter4 = 1;
while($counter4 < 5) {
  echo 'Hallo while: ' . $counter4++.'<br />';
	continue; #ab hier beginnt von vorne und der Rest wird ignoriert
	echo 'weiter <br />';
}
?>
<!--+++++++++++++++++++++++++++++++++++++++-->
<h2>Funktionen für Array(vordefiniert)</h2>
<?php
$liste = ['Apfel','Banane','Mango'];

echo '<p>++++++array_push()++++++++</p>';
#fügt Element hinzu (am Ende des Arrays)
//array_push(wo? welche werte?)
array_push($liste, 'Birne', 201);
#var_dump($liste);
print_r($liste);

echo '<p>++++++array_pop()++++++++</p>';
#Elemente am Ende des array entfernen
array_pop($liste);
print_r($liste);

echo '<p>++++++Elemente am Anfang hinzufügen++++++++</p>'; 
array_unshift($liste, 'Guttenberg','Ali');
print_r($liste);

echo '<p>++++++Element entfernen am Anfang++++++++</p>';
array_shift($liste);
print_r($liste);

echo '<p>++++++array sortieren (A-Z)++++++++</p>';
#sort($liste);
print_r($liste);

echo '<p>++++++array sortieren(Z-A)++++++++</p>';
#arsort($liste);
print_r($liste);

echo '<p>++++++Elemente hinzufügen (mittendrin im Array)++++++++</p>';
#  0  1  2  3  4  5  6
# [1,          2, 3, 4, 5, 6, 7];
#     'Chris' 
//0 bedeutet nichts löschen
array_splice($liste, 1, 0, 'Chris');
print_r($liste);

echo '<p>++++++Elemente löschen (mittendrin im Array)++++++++</p>';
/*
array_splice(arrayName, wo soll ich anfangen?, wieviele Elemente löschen?)
1 bedeutet => du fängst bei dem index 1 an
2 bedeutet => du solls 2 Elemente löschen
*/

#  0  1  2  3  4  5  6
# [1, 2, 3, 4, 5, 6, 7];
#        
#array_splice($liste, 2, 3);
print_r($liste);

echo '<p>++++++shuffle++++++++</p>';
#Elemente eines Arrays mischen
#shuffle($liste);
print_r($liste);

echo '<p>++++++Array zu einem String++++++++</p>';
# $liste = ['Apfel','Banane','Mango'];
# 'ApfelBananeMango'
echo implode(" <=> ",$liste);

echo '<br />';
$a = implode(" - ",$liste);
var_dump($a);

echo '<p>++++++array_search+++++</p>';
#durchsucht ein array nach einem wert
$suche1 = array_search('Apfel',$liste);
var_dump($suche1);
#wird Schlüssel ausgegeben
echo '<br />';
$suche2 = array_search('Hallo',$liste);
var_dump($suche2);
#wird false ausgegeben (nicht vorhanden)

echo '<p>++++++count+++++</p>';
#Zählt die Elemente eines Arrays
echo count( $liste );
?>
<!--+++++++++++++++++++++++++++++++++++++++-->
<h2>Funktionen in PHP (eigene)</h2>
<?php
/*
function nameDerFunktion() {
  Anweisungen;
}

Aufruf der Funktion
nameDerFunktion();
*/

#phpinfo();

function gruss() {
  echo '<p>Hallo Welt</p>';
}

gruss();
/*
gruss();
gruss();
gruss();
gruss();

function gruss1() {
  echo '<p>Hallo Robert</p>';
}

function gruss2() {
  echo '<p>Hallo Thomas</p>';
}

function gruss3() {
  echo '<p>Hallo Zoia</p>';
}
*/
?>
<!--+++++++++++++++++++++++++++++++++++++++-->
<h2>Funktion mit Parametern</h2>
<?php
function ausgabe($wert) {
  echo 'Hallo ' . $wert . '<br />';
  #echo 'Hallo ' . 'Maria' . '<br />';
}

ausgabe('Maria');
ausgabe('Masoud');
ausgabe('Thomas');
ausgabe('Olivier');
?>
<!--+++++++++++++++++++++++++++++++++++++++-->
<form action="#" method="POST" class="col-md-6 bg-primary p-2 m-2">
  <div class="p-1">
    <input type="text" name="nachname" class="form-control" placeholder="Name eingeben" />
  </div>
  <div class="p-1">
    <input type="text" name="vorname" class="form-control" placeholder="Vorname eingeben" />
  </div>
  <div class="p-1">
    <input type="text" name="age" class="form-control" placeholder="Alter eingeben" />
  </div>
  <div class="p-1">
    <input type="submit" value="senden" name="btn" class="btn btn-success fw-bold" />
  </div>
</form>
<?php
#bsp_schleifen_array_form.php?nachname=Merkel&vorname=Angela&age=45&btn=senden#

#bsp_schleifen_array_form.php?blabla=hallo

#bsp_schleifen_array_form.php?nachname=Hans+werner&vorname=Jürgen&age=12&btn=senden#

#Hans&Werner
#bsp_schleifen_array_form.php?nachname=Hans%26Werner
/*
?vorname=Angie&nachname=Hans%26Werner&age=23

https://www.torsten-horn.de/techdocs/ascii.htm

hier passiert URL-Encodierung (bei bestimmten Zeichen z.B. &)
weil & auch für Verkettung benutzt wird

[vorname] => Angie
[nachname] => Hans&Werner
[age] => 23
-----------------------------------------------
POST ist nicht sicherer als GET
NUR eine andere Methode um Daten zu übertragen
##################-
Wann POST und wann GET?

GET => ZeichenLimit in Adresse
			 Nicht für längere Texte geeignet
			 je nach Browserversion -> 2000 - 8000 Zeichen
			 
			 Für Suchformulare, Forms, die Daten übertragen aber nichts im System verändern

POST => Formular wird separat übertragen
				Kein Zeichenlimit
				
				Für Einträge anlegen, löschen, verändern
*/
?>
<!--+++++++++++++++++++++++++++++++++++++++-->
<h2>GET</h2>
<pre><?php print_r($_GET)?></pre>

<h2>POST</h2>
<pre><?php print_r($_POST)?></pre>

<h2>urlencode()</h2>
<?php
#echo urlencode('%');
#echo urlencode('&');
#echo urlencode(' ');
#echo urlencode('+');
#echo urlencode('  '); #2 mal Leerzeichen
?>
<!--+++++++++++++++++++++++++++++++++++++++-->
<h2>Daten vom Formular anzeigen</h2>
<?php
if(isset($_POST['btn'])) {

  if(!empty($_POST['nachname']) || !empty($_POST['vorname']) ) {
    echo 'Hallo ' . $_POST['nachname'] . ', ' . $_POST['vorname'];
  } else {
    echo 'Bitte Name und Vorname eingeben';
  }

  if( empty($_POST['age']) ) {
    echo '<p>Alter darf nicht leer sein</p>';
  }
  else if(!is_numeric($_POST['age'])) {
    echo '<p>Alter darf NUR Zahlen haben</p>';
  }
  else {
    echo '<p>Dein Alter: '. $_POST['age'] .'</p>';
  }
  

}

#is_numeric — Prüft, ob eine Variable eine Zahl oder ein numerischer String ist 

#Bootstrap Breakpoints
#https://getbootstrap.com/docs/5.3/layout/breakpoints/
?>
<!--+++++++++++++++++++++++++++++++++++++++-->
</div>
</body>
</html>