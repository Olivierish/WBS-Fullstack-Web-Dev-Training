<?php

declare(strict_types = 1);
#strikten Umgang mit Typen definieren, 
#dann verlangt PHP, dass genau die Typen lieferegeliefert werden, die in der Funktion definiert sind. 
########################################################
/*
um PHP mitzuteilen, wie detailiert über Probleme berichtet werden soll, gibt es die Funktion 
error_reporting();

Diese erwartet für dem ersten Parameter einen Integerwert, der das sogenannte Error Level festlegt.

0 = hide all errors, warning and notices
E_ALL = show all errors, warnings and notices

error_reporting(E_ERROR | E_WARNING | E_PARSE);
*/
error_reporting(E_ALL);

########################################################
echo '<h2>Typumwandlung</h2>';

function summe(int $a, int $b):int {
  return $a + $b;
}

echo summe(2, 4);
echo '<br />++++++++++++++++++++<br />';
#echo summe("2", 4); #nach strict geht das nicht mehr
#PHP wandelt die Typen auch bei den return Types automatisch in den passenden Datentyp um.

#warum bekommen wir hier keinen Fehler?
#standargmäßig zwingt PHP Werte des falschen Typs in die erwartete Typdeklaration, wenn es möglich ist.
/*
PHP wählt folgenede Reihenfolge für die Typdeklation:
1-int
2-float
3-string
4-bool

Ist keine automatische Umwandlung möglich, erhalten wir eine Fehlermeldung

Umdieses Verhalten der automatischen Umwandlung zu verbieten, kann man dem PHP mitteilen, dass unsere Typdeklation strikt einzuhalten ist.
*/
#is_int — Prüft, ob eine Variable vom Typ int ist
#is_float — Prüft, ob eine Variable vom Typ float ist
#is_array — Prüft, ob die Variable ein Array ist
#-------------------------------------------------------
#strval — Ermittelt die String-Repräsentation einer Variable
#floatval — Konvertiert einen Wert nach float
#intval — Konvertiert einen Wert nach integer
echo '<br />++++++++++++++++++++<br />';
echo summe(intval("5"), 8);
########################################################
$konto1 = [
  'iban'  => 'DE123456789',
  'name'  => 'Max Mustermann',
  'guthaben' => 800
];

$konto2 = [
  'iban'  => 'DE234567889',
  'name'  => 'Hide Boss',
  'guthaben' => 1300
];


function kontoAusgabe($userKonto) {
  echo "Der Kontostand von {$userKonto['name']} ist:  {$userKonto['guthaben']}";
}

#kontoAusgabe([]); #weil er nach guthaben und Name sucht
#kontoAusgabe([]);

echo '<br />';
kontoAusgabe($konto1);
echo '<br />';
kontoAusgabe($konto2);
#-----------------------------------------------------
function transfer($from, $to, $amount) {
  if($from['guthaben'] > $amount) {
		$from['guthaben'] = $from['guthaben'] - $amount;
		$to['guthaben'] = $to['guthaben'] + $amount;
	}
}
transfer($konto1, $konto2, 200);


