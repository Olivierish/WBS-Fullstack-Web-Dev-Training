<div class="col-12">

<form action="#" method="POST" class="rounded-1 p-2"> 
<fieldset class="border border-light border-2 p-1 rounded-2">
	<legend class="text-center">Kontakt</legend>
	<div class="p-1">
		<input type="text" name="name" class="form-control my-1" value="" placeholder="Name eingeben..."	value = "" />
		<input type="text" name="mail" class="form-control my-1" value="" placeholder="E-Mail eingeben..."	value = "" />
		<input type="text" name="betreff" class="form-control my-1" value="" placeholder="Betreff eingeben..."	value = "" />
		<textarea  name="nachricht" cols="10" rows="5" placeholder="Ihr Text..." class="form-control my-1"></textarea>
	</div>
	<div class="my-1 text-center">
		<input type="submit" value="Absenden" name="btnKontakt" class="btn btn-primary w-50 py-2 fs-5" />
	</div>
</fieldset>
</form>

</div>
