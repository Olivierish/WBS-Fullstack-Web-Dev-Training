<?php 

function bereinige($userEingabe, $encoding='UTF-8') {
  #return htmlentities($userEingabe , ENT_QUOTES | ENT_HTML5, $encoding);
  #return htmlentities(trim($userEingabe) , ENT_QUOTES | ENT_HTML5, $encoding);
  return htmlentities( strip_tags(trim($userEingabe)) , ENT_QUOTES | ENT_HTML5, $encoding);
}

function zeichenEntfernen($zeichen) {
  $suche = [
            '{', 
            '}',
            '(',
            ')',
            '=',
            '$',
            '[',
            ']',
            '@'
          ];
  return str_replace( $suche, '', $zeichen );
}

/*
XSS - CROSS SITE SCRIPTING

Angreifer platziert Schadcode auf unserer Webseite
Andere Benutzer bekommen diesen Schadcode ausgeliefert

In den Feldern kann man HTML, JS, alles möglichen Code rein tun
Das landet alles in die Datenbank (falls die Daten dort gespeichert werden sollen)

z.B. eine Weiterleitung
<script>document.location.href = 'http://www.spiegel.de'</script>
#############################################################
https://www.php.net/manual/en/function.htmlentities.php
https://www.php.net/manual/de/function.htmlspecialchars.php
#############################################################

zeichenEntfernen(nachname = function(){anweisungen}) {
  return str_replace( $suche, '', nachname );
}

bereinige(nachname=<h2>Helene</h2>) {
  return htmlentities( &lt;h2&gt;Helene );
}
#############################################################
htmlspecialchars(
    string $string,
    int $flags = ENT_COMPAT,
    ?string $encoding = null,
    bool $double_encode = true
): string
#############################################################
htmlentities(
    string $string,
    int $flags = ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401,
    ?string $encoding = null,
    bool $double_encode = true
): string
#############################################################
strip_tags()
strip_tags — Entfernt HTML- und PHP-Tags aus einem String

strip_tags('userEingabe', '<p><a>');  //hier sind p und a erlaubt
------
Diese Funktion sollte nicht verwendet werden, um zu versuchen XSS-Attacken zu verhindern. 
Statt dessen sind geeignetere Funktionen wie htmlspecialchars() oder andere Mittel, abhängig vom Ausgabekontext, zu verwenden. 
*/
