<?php
session_start();

#logout sollte die Sitzung beenden
/*
#Löschen aller Session-Variablen.
$_SESSION = array();
#----------------------------------
unset($_SESSION['nn']);
unset($_SESSION['vn']);
unset($_SESSION['mail']);
*/
#----------------------------------
#die ganze sessionDatei entfernen bzw. löschen
session_destroy();

#Weiterleitung zu index und eine Meldung ausgeben
header('Location: ../index.php?msg=off');