<!DOCTYPE html>
<html lang="de">
<head>
	<meta charset="utf-8" /> 
	<title>php</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="../bootstrap/css/bootstrap.css" />
</head>
<body class="bg-dark bg-opacity-75">
<div class="container bg-light">
<header class="row bg-dark">
	<div class="col-md-8">
		<nav class="navbar navbar-expand navbar-dark">
		<ul class="navbar-nav">
			<li class="nav-item">
				<a href="index.php" class="nav-link">Home</a>   
			</li>
			<li class="nav-item">
				<a href="index.php?page=daten" class="nav-link">OOP</a>
			</li>
			<li class="nav-item">
				<a href="index.php?page=register" class="nav-link">Registrierung</a>
			</li>
		</ul>
		</nav>
	</div>
	<!--++++++-->
	<div class="col-md-4 p-1">
		<?php
			#wenn angemeldet dann diesen Bereich anzeigen
			if(isset($_SESSION['mail'])): 
				echo '<p class="text-light fs-2">Hallo '.$_SESSION['nn']. ', ' . $_SESSION['vn'] .'</p>';
				echo '<p><a href="inc/logout.php" class="btn btn-warning btn-sm">Logout</a></p>';
			else:
			#wenn NICHT angemeldet dann diesen Bereich anzeigen
		?>
		<form class="bg-light p-2" action="inc/login.php" method="post">
			<input type="text" name="nachname" placeholder="Bitte Name eingeben" />
			<input type="text" name="vorname" placeholder="Bitte Vorname eingeben" />
			<input type="text" name="mail" placeholder="Bitte E-Mail eingeben" />
			<input type="submit"  value="einloggen" class="btn btn-success w-100 my-1" />
		</form>
		<?php endif; ?>

		<?php
		#die Meldungen kommen aus login.php und logout.php
		if(isset($_GET['msg'])):
			if($_GET['msg'] == 'errorNN') {
				echo '<p class="bg-light text-danger p-1">Nachname darf Nur Buchstaben haben</p>';
			}
			else if($_GET['msg'] == 'errorVN') {
				echo '<p class="bg-light text-danger p-1">Vorname darf Nur Buchstaben haben</p>';
			}
			else if($_GET['msg'] == 'errorM') {
				echo '<p class="bg-light text-danger p-1">Muster für E-Mail: test@test.de</p>';
			}
			else if($_GET['msg'] == 'off') {
				echo '<p class="bg-light text-danger p-1">Logout erfolgreich!</p>';
			}
		endif;
		?>
	</div>
</header>
<main class="row p-2">

 
