<?php

$zeichenMuster = "/^[a-zäöüß]{1}[a-zäöüß\s\-]{1,19}$/i";
$mailMuster = "/^[a-zA-Z0-9\.]+@[a-zA-Z\-]+\.[a-zA-Z]+$/";
#------------------------------------------------
if( !preg_match($zeichenMuster, $_POST["nachname"]) ) {
  header("Location: ../index.php?msg=errorNN");
}
else if( !preg_match($zeichenMuster, $_POST["vorname"]) ) {
  header("Location: ../index.php?msg=errorVN");
}
else if( !preg_match($mailMuster, $_POST["mail"]) ) {
  header("Location: ../index.php?msg=errorM");
}
else {
  session_start();
  //wenn alels ok ist dann eine Sitzung starten
  $_SESSION['nn'] = $_POST["nachname"];
  $_SESSION['vn'] = $_POST["vorname"];
  $_SESSION['mail'] = $_POST["mail"];

  header("Location: ../index.php");
}
###################################################

/*
* Daten zum Nutzer speichern
* Unterliegen NICHT der DSGVO
* Daten werden auf dem Server gespeichert
* Schwer Manipulierbar
* Kann für nicht kritische Informationen verwendet werden (Userdaten usw.)
* Wird für die Funktionalität des Projekts verwendet

Ablauf
* Am Anfang der Seite mit session_start() starten
* Daten werden auf dem Server gespeichert
* Beim Ausloggen wird die Session gelöscht
Server 																						Browser
					Browser bekommt zufälligen Cookie.
					Name. PHPSESSID
					
					Daten werden nicht an den Browser übertragen und bleiben
					temporär beim Server
					Die Zuordnung erfolgt über die PHPSESSID
					
Session kann nicht manipuliert werden weil beim Server

###################################################
#Sicherheit von cookie

* Keine SQL - Injection 
* kein Cross-Site-Scripting

Problem
* HTTP kann mitgeschnitten werden
* Beispiel: Offenes WLAN am BHF
* Angreifer kann komplette HTTP - Anfrage + Antwort mitschneiden
* Bekommt damit auch die Cookie / Session von uns
-----------------------------
* Ein Angreifer kann kompletten Zugriff auf den Computer haben
* Kopiert alle Cookies auf einen USB
* Kann Webseiten dann eingeloggt von einem anderen Computer aus nutzen

Lösung
* Verschlüsselung der Verbindung (HTTPS)
* Bei HTTPS-Warnung: Seite sofort verlassen
------------------------------
* Absichern von kritischen Vorgängen durch Verwendung von mehreren Geräten
* Beispiel: TAN für Online-Überweisungen

###################################################
#PHPSESSID neu generieren
#wegen der Sicherheit eine neue PHPSESSID erzeugen

session_regenerate_id(bool $delete_old_session = false): bool

Die Funktion session_regenerate_id() ersetzt die aktuelle Session-ID durch eine neue und übernimmt die aktuellen Session-Informationen. 

$_SESSION['lastname'] = 'Mustermann';
$_SESSION['firstname'] = 'Anna';

print_r($_SESSION);

echo '<br />';
print_r( session_save_path() );
#SpeicherOrt von session
*/