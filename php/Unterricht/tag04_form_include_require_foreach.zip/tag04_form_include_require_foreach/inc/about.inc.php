<h2>About Design</h2>

<?php
$daten = [
	[
		'anrede' => 'herr',
		'name' => 'tom',
		'city' => 'Hamburg',
		'age' => '25',
		'interests' => ['PHP','JavaScript','Laravel'],
	],
	[
		'anrede' => 'frau',
		'name' => 'anna',
		'city' => 'Berlin',
		'age' => '22',
		'interests' => ['React','JSON','XML','Vue.js'],
	],
	[
		'anrede' => 'herr',
		'name' => 'jerry',
		'city' => 'Paris',
		'age' => '35',
		'interests' => ['HTML','CSS'],
	],
	[
		'anrede' => 'frau',
		'name' => 'helene',
		'city' => 'Palma',
		'age' => '21',
		'interests' => ['PHP','CMS','Photoshop','Laufen','Malen'],
	]
];
?>

<h2>for-Schleife</h2>
<div class="row">

<?php for($i = 0; $i < count($daten); $i++):?>
<?php ?>
	<ul class="<?= $daten['anrede'] == 'herr' ? 'bg-info' : 'bg-warning';?> col-md-4 m-2">
		<li><b><?= strtoupper($daten[$i]['anrede'] .' '.$daten[$i]['name']); ?></b></li>
		<li>Wohnort: <?= $daten[$i]['city']; ?></li>
		<li>Alter: <?= $daten[$i]['age']; ?>j.</li>
		<li>Interessen (<?= count($daten[$i]['interests']) ?>): 
			<?php
				/*foreach($daten[$i]['interests'] AS $interes):
					echo '<p>'. $interes .'</p>';
				endforeach;
				*/
				for($j =0; $j < count($daten[$i]['interests']); $j++):
					echo '<p>'. $daten[$i]['interests'][$j] .'</p>';
					#print_r($daten[$i]['interests']);
				endfor;
			?>
		</li>
	</ul>
<?php endfor;?>
</div>

<h2>foreach-Schleife</h2>
<div class="row">

<?php foreach($daten AS $value):?>
<?php ?>
	<ul class="<?= $value['anrede'] == 'herr' ? 'bg-info' : 'bg-warning';?> col-md-4 m-2">
		<li><b><?= strtoupper($value['anrede'] .' '.$value['name']); ?></b></li>
		<li>Wohnort: <?= $value['city']; ?></li>
		<li>Alter: <?= $value['age']; ?>j.</li>
		<li>Interessen (<?= count($value['interests']) ?>): 
			<?php
				foreach($value['interests'] AS $interes):
					echo '<p>'. $interes .'</p>';
				endforeach;
			?>
		</li>
	</ul>
<?php endforeach;?>
</div>