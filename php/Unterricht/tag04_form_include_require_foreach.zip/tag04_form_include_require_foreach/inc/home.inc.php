<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="POST" class="bg-success col-md-6 bg-opacity-10 rounded-2 p-3">
	<div class="my-1">
		<label for="frau" class="form-check-label">Frau</label>
		<input type="radio" name="anrede" value="Frau" id="frau" class="form-check-input" />
		<label for="herr" class="form-check-label">Herr</label>
		<input type="radio" name="anrede" value="Herr" id="herr" class="form-check-input" />
	</div>
	<div class="my-1">
		<input type="text" name="vorname" placeholder="Vorname eingeben" class="form-control" />
	</div>
	
	<div class="my-1">
		<input type="text" name="nachname" placeholder="Nachname eingeben" class="form-control"  />
	</div>
	
	<div class="my-1">
		<input type="password" name="pwd" placeholder="Passwort eingeben" class="form-control" />
	</div>

	<div class="my-1">
		<input type="text" name="wohnort" placeholder="Wohnort eingeben" class="form-control" />
	</div>
	<!--++++++-->
	<div class="my-1">
		<label for="tanzen" class="form-check-label">Tanzen</label>
		<input type="checkbox" value="Tanz" name="hobby[]" id="tanzen" class="form-check-input">
		
		<label for="singen" class="form-check-label">Singen</label>
		<input type="checkbox" value="Singen" name="hobby[]" id="singen" class="form-check-input">
		
		<label for="laufen" class="form-check-label">Laufen</label>
		<input type="checkbox" value="Laufen" name="hobby[]" id="laufen" class="form-check-input">
	</div>


	<div class="my-1">
		<select name="fach" class="form-select">
			<option>Bitte Ihr Lieblingsfach auswählen</option>
			<option>HTML</option>
			<option>JS</option>
			<option>PHP</option>
			<option>MYSQL</option>
			<option>Laravel</option>
		</select>
	</div>
	
	<div>
		<input type="submit" value="senden" class="btn btn-success" name="btnRegister" />
		<input type="reset" value="löschen" class="btn btn-danger"  />
	</div>
</form>
<!--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->
<div class="row">
<div class="col-12">
<?php
#hier wird nur die Schaltfläche angesprochen, die den name="btnRegister" hat
if(isset($_POST['btnRegister'])) {
  #Felder dürfen nicht leer sein
  if( empty($_POST['anrede']) || 
      empty($_POST['vorname']) || 
      empty($_POST['nachname']) ||
      empty($_POST['pwd']) ||
      empty($_POST['wohnort']) ||
      empty($_POST['hobby']) ||
      empty($_POST['fach']) 
    ):
    echo '<p>Bitte alle Felder ausfüllen</p>';
  else:
    #wenn alles ok dann Daten anzeigen
    $anrede = $_POST['anrede'];
	  $vorname = $_POST['vorname'];
	  $nachname = $_POST['nachname'];
	  $ort = $_POST['wohnort'];
	  $pwd = $_POST['pwd'];
	  $hobby = $_POST['hobby'];
	  $fach = $_POST['fach'];
    #------------------------------------
    echo '<div class="bg-primary text-light p-2"><p>Vielen Dank für Ihre Angaben</p>';
    echo '<p>' . $anrede .' '. $nachname .', '. $vorname.'</p>';
    echo '<p><b>Passwort: </b>'. $pwd[0].'*****' . $pwd[-1].  '</p>';
    echo '<p><b>Wohnort: </b>'. $ort . '</p>';
    echo '<p><b>Fach: </b>'. $fach . '</p>';
    #echo '<p>Hobbies: ' . $_POST['hobby']. '</p>';
    echo '<p><b>Hobbies: </b>';
    foreach($hobby AS $value) {
      echo $value . ' ';
    }
    echo '</p></div>';
  endif;



}#ende isset

/*
POST ist nicht sicherer als GET
NUR eine andere Methode um Daten zu übertragen
###############################################
Wann POST und wann GET?

GET => ZeichenLimit in Adresse
			 Nicht für längere Texte geeignet
			 je nach Browserversion -> 2000 - 8000 Zeichen
			 
			 Für Suchformulare, Forms, die Daten übertragen aber nichts im System verändern

POST => Formular wird separat übertragen
				Kein Zeichenlimit
				
				Für Einträge anlegen, löschen, verändern
				
$_REQUEST => kann Daten von $_GET und $_POST übertragen

$_SERVER — Informationen über Server und Ausführungsumgebung

'PHP_SELF'
    Der Dateiname des aktuell ausgeführten Skripts, relativ zum Document-Root. Beispielsweise enthält
		
'SCRIPT_NAME'
    Enthält den Pfad zum aktuellen Skript. Dies ist nützlich für Seiten, die auf sich selbst verweisen sollen.
		
'SCRIPT_FILENAME'
    Der absolute Pfad des aktuell ausgeführten Skripts.
		
'REQUEST_METHOD'
    Die Requestmethode, die verwendet wurde, um die Seite aufzurufen; z. B. 'GET', 'HEAD', 'POST', 'PUT'. 

<h2>$_REQUEST</h2>
<pre><?php print_r($_REQUEST);?></pre>

<h2>$_SERVER</h2>
echo $_SERVER['PHP_SELF'] . '<br />';

echo $_SERVER['SCRIPT_NAME'] . '<br />';

echo $_SERVER['SCRIPT_FILENAME'] . '<br />';

<pre><?php #print_r($_SERVER);?></pre>
*/
?>
</div>
</div>
