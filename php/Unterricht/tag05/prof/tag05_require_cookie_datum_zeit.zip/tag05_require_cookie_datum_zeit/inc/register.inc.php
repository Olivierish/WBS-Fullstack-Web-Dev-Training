<form action="index.php?page=cookie" method="POST" class="bg-primary col-md-6 bg-opacity-10 rounded-2 p-3">
	<div class="my-1">
		<input type="text" name="vorname" 
						placeholder="Vorname eingeben" 
							class="form-control"
							value="<?= $_COOKIE['vorname'] ?? '' ; ?>" />
	</div>
	
	<div class="my-1">
		<input type="text" name="nachname" 
						placeholder="Nachname eingeben" 
							class="form-control"
							value="<?= $_COOKIE['nachname'] ?? '' ; ?>"  />
	</div>
	
	<div class="my-1">
		<input type="text" name="mail" 
						placeholder="E-Mail eingeben" 
								class="form-control"
								value="<?= $_COOKIE['email'] ?? '' ; ?>"  />
	</div>

	<div class="my-1">
		<input type="password" name="pwd" placeholder="Passwort eingeben" class="form-control" />
	</div>
	
	<div>
		<input type="submit" value="senden" class="btn btn-success" name="btnRegister" />
		<input type="reset" value="löschen" class="btn btn-danger"  />
	</div>
</form>

<div class="row">
<?php
if(isset($_POST['btnRegister'])) {

echo '<div class="alert alert-primary my-4 col-md-6">';
	if(empty($_POST['vorname']) || 
		 empty($_POST['nachname']) || 
		 empty($_POST['mail']) || 
		 empty($_POST['pwd'])
		) {
			echo 'Bitte Daten eingeben';
	} else {
		#---------------------------
		$firstname = $_POST['vorname'];
		$lastname = $_POST['nachname'];
		$mail = $_POST['mail'];
		#---------------------------
		#setcookie()
		#60*60*24*30 => 30 Tage
		#time() + 3600 => verfällt in 1std
	
		# time()-3600 Zeit in der Vergangenheit => wird sofort gelöscht
		#Um ein Cookie zu löschen, muss man einen Zeitpunkt in der Vergangenheit angeben. 
		#Dadurch erkennt der Browser, dass dieser Cookie abgelaufen ist, und löscht diesen:
		
		setcookie('vorname',$firstname, time() + 60 * 60 * 24 * 30);
		setcookie('nachname',$lastname, time() + 3600);
		setcookie('email',$mail, time() - 3600);
		#---------------------------
		echo "<p>Hallo $firstname $lastname <br />E-Mail: $mail</p>";
		#---------------------------
	}#ende else
echo '</div>';

}#ende isset

#############################################################
#cookies anzeigen
/*
* Unterliegen der DSGVO
* Speichert Daten beim User (Browser)
* Manipulierbar
* Ablaufzeit kann festgelegt werden
* Wird verwendet für nicht kritische Informationen
* Wird benutzt um Daten zu tracken (Surfverhalten, Speichern von Eingabedaten in form)

Ablauf
* Mit setcookie() Daten speichern
* Nutzer kann jederzeit die Cookies sehen und löschen
* Ablaufzeit kann bestimmt werden

#noch keine cookies vorhanden
#print_r($_COOKIE); 

#cookies kann  so erstellt werden
#header('Set-Cookie: name=Max');
#header('Set-Cookie: name=Jerry');
#print_r($_COOKIE);

#cookies kann man auch mit der Funktion setcookie() erstellen
#etwas komfortablere Schreibweise

setcookie(string $name, string $value = "", array $options = []): bool

setcookie() definiert ein mit den HTTP-Header-Informationen zu übertragendes Cookie. 
*/
?>
</div>

