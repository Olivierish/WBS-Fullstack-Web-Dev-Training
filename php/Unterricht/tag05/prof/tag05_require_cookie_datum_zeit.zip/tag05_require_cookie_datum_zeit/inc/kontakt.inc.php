<h2>Kontakt</h2> 

<div class="row">
<div class="col-12">

<table class="table my-2 table-striped table-danger">
  <tr> <td>Zelle</td> <td>Zelle</td> <td>Zelle</td> </tr>
  <tr> <td>Zelle</td> <td>Zelle</td> <td>Zelle</td> </tr>
  <tr> <td>Zelle</td> <td>Zelle</td> <td>Zelle</td> </tr>
  <tr> <td>Zelle</td> <td>Zelle</td> <td>Zelle</td> </tr>
  <tr> <td>Zelle</td> <td>Zelle</td> <td>Zelle</td> </tr>
</table>
<!--+++++++++++++++++++++++++++++++++++++++++++-->
<table class="table my-2 table-striped table-primary w-50">
  <thead>
    <tr> <th>Name</th> <th>Vorname</th> <th>E-Mail</th> </tr>
  </thead>
  <tbody>
    <tr> <td>Zelle</td> <td>Zelle</td> <td>Zelle</td> </tr>
    <tr> <td>Zelle</td> <td>Zelle</td> <td>Zelle</td> </tr>
    <tr> <td>Zelle</td> <td>Zelle</td> <td>Zelle</td> </tr>
    <tr> <td>Zelle</td> <td>Zelle</td> <td>Zelle</td> </tr>
  </tbody>
</table>
<!--+++++++++++++++++++++++++++++++++++++++++++-->
<table class="table my-2 table-striped table-dark caption-top">
  <caption class="bg-dark text-light text-center fs-2">Liste der Teilnehmer</caption>
  <thead>
    <tr> <th>Name</th> <th>Vorname</th> <th>E-Mail</th> </tr>
  </thead>
  <tbody>
    <tr> <td>Zelle</td> <td>Zelle</td> <td>Zelle</td> </tr>
    <tr> <td>Zelle</td> <td>Zelle</td> <td>Zelle</td> </tr>
    <tr> <td>Zelle</td> <td>Zelle</td> <td>Zelle</td> </tr>
    <tr> <td>Zelle</td> <td>Zelle</td> <td>Zelle</td> </tr>
  </tbody>
</table>
<!--+++++++++++++++++++++++++++++++++++++++++++-->
<?php
#-----------------------------------------
/*
#$text = 'Hallo Welt, ich grüße die Welt';
#-----------------------------------------
#wenn das Wort gefunden wird dann wird die Position angezeigt
#var_dump(strpos($text, 'Welt1'));
#-----------------------------------------
#1 = ja, 0 = nein
#var_dump(preg_match('/Welt/', $text));
#-----------------------------------------
#hauptsache kommt Welt vor
#$text = 'Hallo Weltmeister Welt';
#var_dump(preg_match('/Welt/', $text));
#var_dump(preg_match('/\d/', $text));
#-----------------------------------------
#$text = 'Hallo Weltmeister 20 Welt';
#var_dump(preg_match('/\d/', $text));

#$text = 'Hallo Weltmeister20 Welt'; #passt nicht
#$text = 'Hallo Welt20 Welt'; #passt
#var_dump(preg_match('/Welt\d/', $text));
#-----------------------------------------
#$text = 'Hallo Welt20 Welt';
#$text = 'Hallo 20Welt20 Welt'; #passt
#var_dump(preg_match('/\dWelt\d/', $text));
#-----------------------------------------
#$text = '3 Bananen';
#var_dump(preg_match('/\d\sBananen/', $text));
#-----------------------------------------
#$text = 'dateiName.jpg';
#$text = 'dateiName.pdf'; #passt nicht
#$text = 'hallo dateiName.jpg hallo';
#var_dump(preg_match('/\.(jpg|gif|png)/', $text));
#-----------------------------------------
#$text = 'hallo dateiName.jpg hallo'; #passt nicht
#$text = 'hallo dateiName.jpg';
#mit .jpg gif png endet
#var_dump(preg_match('/\.(jpg|gif|png)$/', $text));
#-----------------------------------------
#$text = 'Hallo 65 Weltmeister20 Welt';
#var_dump(preg_match('/\d+\sWelt/', $text, $suche)); #findet nur eine Sache
#preg_match_all('/\d+\sWelt/', $text, $suche);
#echo '<br />';
#print_r($suche);
#-----------------------------------------
#Rest kommt morgen :-)
*/
?>
</div>
</div>