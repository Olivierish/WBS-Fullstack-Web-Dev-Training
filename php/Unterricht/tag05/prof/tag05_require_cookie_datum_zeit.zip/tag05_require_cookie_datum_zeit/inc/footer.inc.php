</main>
<footer class="row">
	<div class="col-md-6 bg-primary bg-opacity-75 text-light p-1">&copy; by design</div>
	<div class="col-md-6 bg-primary bg-opacity-25 p-1">TERMS AND CONDITIONS</div> 
</footer>
</div>
</body>
</html>
