<h2>Zeit ist Gold</h2>  
<?php
#Sekunden seit 1.1.1970 00:00
echo time();
################################################################
echo '<p>++++++++++++++</p>';
/*
m => Monat
d => Tag
D => Wochentag
y => Jahr 2 stellig
Y => Jahr 4 stellig
H:i:s => std:min:sek

d 	Tag des Monats, zweistellig 	01, 22
j 	Tag des Monats, einstellig 	1, 23
m 	Nummer des Monats, zweistellig 	01, 12
n 	Nummer des Monats, einstellig 	1 bis 12
y 	Jahr, zweistellig 	98, 05
Y 	Jahr, vierstellig 	1998, 2005
H 	Stunden im 24-Stunden-Format, zweistellig 	04, 18
G 	Stunden im 24-Stunden-Format, einstellig 	4, 14
i 	Minuten, zweistellig 	04, 32
s 	Sekunden, zweistellig 	02, 55
w 	Wochentag in Zahlenwert, 0 für Sonntag, 6 für Samstag 	1, 5
*/
#date(string $format, ?int $timestamp = null): string
echo date('d.m.y');

echo '<p>++++++++++++++</p>';
echo date('d.m.Y');

echo '<p>++++++++++++++</p>';
echo date('D d.m.Y');

echo '<p>++++++++++++++</p>';
echo date('d.m.Y H:i:s');

echo '<p>++++++++++++++</p>';
echo date('d.m.Y', time() + (60 * 60 * 24));
echo '<p>++++++++++++++</p>';
# 0   1   2   3   4
# So, Mo, Di, Mi, Do
echo date('w');
echo '<p>++++++++++++++</p>';
#  
# Jan, Feb, März, Apr, Mai, ..., Dez
echo date('n');
################################################################
echo '<p>Monat in Deutsch</p>';
$monat = [
   "Januar",
   "Februar",
   "März",
   "April",
   "Mai",
   "Juni",
   "Juli",
   "August",
   "September",
   "Oktober",
   "November",
   "Dezember"];
#array beginnt bei 0 und date('n') fängt bei 1 an
#deswegen 0+1 1+1 usw.	 
echo $monat[date('n') - 1];
################################################################
echo '<p>Wochentag in Deutsch</p>';
#           0         1         2         3           4           5         6
$tage = ['Sonntag','Montag','Dienstag','Mittwoch','Donnerstag','Freitag','Samstag'];
/*
echo $tage[4]; 
*/
echo $tage[date('w')];
################################################################
echo '<p>mktime()</p>';
#mktime — Liefert den Unix-Zeitstempel für ein Datum
#damit kann man besser rechnen
/*
 mktime(
    int $hour,
    ?int $minute = null,
    ?int $second = null,
    ?int $month = null,
    ?int $day = null,
    ?int $year = null
): int|false
*/

#echo mktime();
################################################################
#Zeitstempel definieren
#echo mktime(18,23,0,2,28,2023);

echo '<br />';
$geboren = mktime(18,23,0,3,1,2000);

$differenz = (time() - $geboren) / (60 * 60 * 24 * 365);

echo 'Maria ist ' . floor($differenz) . 'j JUNG';
echo '<br />';
################################################################
$geb = mktime(0,0,0,6,6,2023);
$diff = ($geb - time()) / (60 * 60 * 24);

echo 'Kamyar hat in ' . floor($diff) . ' Tagen Geburtstag';