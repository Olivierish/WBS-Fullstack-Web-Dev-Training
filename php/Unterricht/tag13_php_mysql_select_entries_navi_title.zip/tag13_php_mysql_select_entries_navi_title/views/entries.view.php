<div class="col-12">
<h2 class="display-5 text-center"><?php echo mb_strtoupper('Gästebuch', 'UTF-8');?></h2>
<!--##############################################-->
<form action="auth/entries/insert.php" method="POST" class="rounded-1 p-2 bg-success bg-opacity-25">
<div class="p-1">
	<input type="text" name="name" class="form-control my-1" placeholder="Name eingeben..."	value = "" />
	<input type="text" name="titel" class="form-control my-1" placeholder="Titel eingeben..."	value = "" />
	<textarea  name="inhalt" cols="10" rows="5" placeholder="Kommentar eingeben..." class="form-control my-1"></textarea>
</div>
<div class="my-1 text-center">
	<input type="submit" value="Absenden" class="btn btn-success fw-bold" />
	<input type="reset" value="Löschen"  class="btn btn-danger fw-bold" />
</div>
</form>
<!--##############################################-->
<hr class="hr my-4 text-dark border-3" />
<!--##############################################-->
<?php
$stmt = $db->prepare('SELECT * FROM `entries`');
$stmt->execute();
$posts = $stmt->fetchAll();
?>
<pre><?php #print_r($posts);?></pre>

<div class="col-12">
<h2>Gästebuch</h2>

<?php foreach($posts AS $post):?>
<div class="card my-2">
  <div class="card-header">
    <div class="row">
      <h3 class="col-md-6 text-dark"><?= $post['title']?></h3>
      <span class="col-md-6 name text-end"><?= $post['name']?></span>
    </div>
  </div>
  <div class="card-body"><?= nl2br($post['comment'])?></div>
</div>
<?php endforeach;?>

</div>

<?php 
#"\n" muß in "" stehen sonst wird nicht als newLine erkannt 
#$content = "Hallo Welt\nHallo PHP\nHallo JS";

#echo $content;

#nl2br — Fügt vor allen Zeilenumbrüchen eines Strings HTML-Zeilenumbrüche ein
#echo nl2br($content);

#wir wollen aber Absätze erzeugen
#<p>Hallo Welt</p> <p>Hallo PHP</p> <p>Hallo JS</p>

#$absatz = explode("\n", $content);
#$absatz = ["Hallo Welt", "Hallo PHP", "Hallo JS"];
?>
<pre><?php #var_dump($content);?></pre>
<pre><?php #var_dump($absatz);?></pre>
<?php
#<p>Hallo Welt#Hallo PHP#Hallo JS</p>
#echo '<p>' . implode('#', $absatz) . '</p>';

#<p>Hallo Welt</p><p> Hallo PHP</p><p>Hallo JS</p>

#echo '<p>' . implode('</p><p>', $absatz) . '</p>';
#-------------------------------------------------------
#problem: ein user kann auch mehrmals Zeilenumbruch machen und entstehen mehrere leere Absätze
#$content = "Hallo Welt\n\n\nHallo PHP\nHallo JS";
#$absatz = explode("\n", $content);
#echo '<p>' . implode('</p><p>', $absatz) . '</p>';
#-------------------------------------------------------
#lieber so schreiben
$content = "Hallo Welt\n\n\n Hallo PHP\n\n\nHallo JS";
$absatz = explode("\n", $content);
#ein leeres Arary erstellen
$filterAbsatz = [];

foreach($absatz AS $value) {
  $value = trim($value);
  #wenn ein Wert leer ist dann gibt String = 0
  #sowas wollen wir nicht haben
  #\n => "" => 0
  #wenn ein User mehrmals Zeilenumbruch klickt dann wird ignoriert
  if(strlen($value) > 0) {
    #Array bekommt hier die Werte, die vorher zerlegt wurden
    /*
    $filterAbsatz[] = "Hallo Welt";
    $filterAbsatz[] = "Hallo PHP";
    $filterAbsatz[] = "Hallo JS";
    Ergebnis ist:
    $filterAbsatz = [Hallo Welt","Hallo PHP","Hallo JS"]
    */
    $filterAbsatz[] = $value;
  } 
}

#$filterAbsatz = [Hallo Welt","Hallo PHP","Hallo JS"]
var_dump($filterAbsatz);
#---------------------------
/*
$filterAbsatz hat jetzt mehrere Werte (ist ein Array)
Jeden einzelnen Wert in ein <p></p> rein tun
*/
foreach($filterAbsatz AS $element) {
  echo '<p>' . $element .'</p>';
}

?>

