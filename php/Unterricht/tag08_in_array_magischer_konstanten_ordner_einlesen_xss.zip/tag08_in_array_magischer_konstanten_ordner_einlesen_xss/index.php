<!DOCTYPE html>
<html lang="de">
<head>
	<meta charset="utf-8" /> 
	<title>php</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="../bootstrap/css/bootstrap.css" />
</head>
<body class="bg-dark bg-opacity-75">
<div class="container bg-light">
<header class="row bg-warning">
	<div class="col-12 p-2">
		<h1 class="display-1">design follows function</h1>
	</div>
</header>
<main class="row p-2">
<?php

#								0						1							2
$zahlen = [	[1,2,3,4],	[5,6,7,8,10],	[33,44,55] ];
#						 0 1 2 3     0 1 2 3 4      0  1 2

for($i = 0; $i < count($zahlen); $i++) {
	#echo $zahlen[$i][$i];
	#echo $zahlen[0][0];
	#echo $zahlen[1][1];
	#echo $zahlen[2][2];
	
	echo '<p>';
	for($j = 0; $j < count($zahlen[$i]); $j++) {
		#if($i == 0) continue;
		#if($i == 1) continue;
		#echo $zahlen[$i][$j] . ' ';

		echo $zahlen[$i][$j] * 2 . ' ';
	}
	echo '</p>';
}


##############################################
echo '<h2>Zahlen mit foreach</h2>';
foreach($zahlen AS $liste){
	echo '<p>';
	foreach($liste AS $value) {
		echo $value * 2 . ' ';
	}
	echo '</p>';
}

##############################################
echo '<h2>In Array suchen</h2>';
$liste2 = ['Berlin','Paris','Athen','Lisboa','Madrid','Barcelona','Porto'];

#echo 'Paris'[0]; #1.Buchstabe
#echo 'Paris'[-1]; #letzter Buchstabe
#echo $liste2[2][0];
#echo $liste2[2][-1];
?>
<ul>
<?php foreach($liste2 AS $value):?>
	<?php if($value[0] === 'P'):?>
		<li><?= $value?></li>
	<?php endif;?>
<?php endforeach;?>
</ul>
<!--wenn ein Eintrag nicht gefunden wird dann wird immernoch ein leeres <ul> erstellt.
Lieber so wie unten schreiben-->
<?php
#erstmal ein leeres array erstellen
$filter = [];
foreach($liste2 AS $value) {
	if($value[0] === 'P') {
		$filter[] = $value;
	}
}

print_r($filter);
?>
<!--##############################################-->
<h2>In Array suchen (nur gefiltered anzeigen)</h2>
<?php if(!empty($filter)):?>
<ul>
<?php foreach($filter AS $city):?>
		<li><?= $city?></li>
<?php endforeach;?>
</ul>
<?php endif;?>
<!--##############################################-->
<h2>XSS</h2>
<form action="<?= $_SERVER["PHP_SELF"];?>" method="get">
<div class="p-1">
	<!--<input type="text" name="name" class="form-control" value = "<?php # echo strip_tags ($_GET['name']) ?? '' ?>" />-->
	<input type="text" name="name" class="form-control" 
					value = "<?= isset($_GET['name']) ? sauberHTML($_GET['name']) : ''?>" />
</div>
<input type="submit" value="Info zeigen" name="btn" class="btn btn-success fw-bold my-1" />
</form>
<?php
#?name=<img src="...." onerror="document.location.href='https://www.spiegel.de' " />
#echo $_GET['name'];

#echo strip_tags($_GET['name']);
#?name=<h2>Hallo</h2> #html-Elemente werden entfernt

#echo '<h1>' .strip_tags($_GET['name']) . '</h1>';
#"onclick= "alert('Hallo');
#<img src="...." onclick= "alert('Hallo'); " />

#nur strip_tags() reicht nicht aus

function sauberHTML($html) {
	return htmlentities($html, ENT_QUOTES, 'UTF-8' );
}


#echo '<h1>' . sauberHTML($_GET['name']) . '</h1>';
?>
<!--##############################################-->
<h2>Seiten - anzeigen</h2>
<form action="<?php $_SERVER["PHP_SELF"];?>" method="get">
<div class="p-1">
	<select name="city">
		<option value="hamburg">Hamburg</option>
		<option value="helgoland">Helgoland</option>
		<option value="rotterdam">Rotterdam</option>
	</select>
</div>
<input type="submit" value="Info zeigen" name="cityBtn" class="btn btn-success fw-bold my-1" />
</form>
<?php
#include 'pages/'.$_GET['city'].'.inc.php';
#if(!empty($_GET['city'])) {
	#include führt eine Datei immer als .php aus
	#kein guter still
	#wenn in einer Datei php-code steht dann unter .php speichern
	#include "pages/{$_GET['city']}.inc.html";
	
	#lieber schreiben
	#echo file_get_contents("pages/{$_GET['city']}.inc.html");
	
	#unsicher
	#weil, man kann auch so schreiben (in einen anderen Ordner rein und andere Datei aufrufen)
	#index.php?city=../inc/attacke
#}
#------------------------------------
#eine Möglichkeit
$cities = ['hamburg','helgoland','rotterdam'];

if(!empty($_GET['city']) && in_array($_GET['city'], $cities)) { 
	echo file_get_contents("pages/{$_GET['city']}.inc.html");
}
?>
<!--##############################################-->
<h2>Seiten besser organisieren</h2>
<?php
$staedte = [
					'hamburg' => 'Hansestadt Hamburg',
					'helgoland' => 'Hochseeinsel Helgoland',
					'rotterdam' => 'Rotterdam (NL)'
];

/*
<select name="stadt">
<option value="$key">$value</option>
</select>

<select name="stadt">
<option value="hamburg">Hansestadt Hamburg</option>
<option value="helgoland">Hochseeinsel Helgoland</option>
<option value="rotterdam">Rotterdam (NL)</option>
</select>

hier ist der Wert von stadt, das, was in <option>wert</option> steht
<select name="stadt">
	<option>Hamburg</option>
</select>

hier ist der Wert von stadt, das, was in value von option 
<option value="inhalt">wert</option> steht
<select name="stadt">
	<option value="ichHabeVorrang">Hamburg</option>
</select>
*/
?>
<form action="<?php $_SERVER["PHP_SELF"];?>" method="get">
<div class="p-1">
	<select name="stadt">
		<?php foreach($staedte AS $key => $value):?>
		<option value="<?= $key?>"><?= $value?></option>
		<?php endforeach;?>
	</select>
</div>
<input type="submit" value="Info zeigen" class="btn btn-success fw-bold my-1" />
</form>
<?php
if(!empty($_GET['stadt']) && !empty($staedte[$_GET['stadt']])) { 
	echo file_get_contents("pages/{$_GET['stadt']}.inc.html");
}
?>
<!--##############################################-->
<h2>Ordner einlesen</h2>
<?php
/*
Magische Konstanten
Es gibt neun magische Konstanten, die, abhängig davon, wo sie eingesetzt werden, einen unterschiedlichen Wert haben. 

__LINE__ 	Die aktuelle Zeilennummer einer Datei. 

__FILE__ 	Der vollständige Pfad- und Dateiname einer Datei mit aufgelösten Symlinks. Wird diese Konstante innerhalb einer nachgeladenen Datei verwendet, wird der Name dieser eingebundenen Datei zurückgegeben.

__DIR__ 	Der Name des Verzeichnisses, in dem sich die Datei befindet. Wird die Konstante innerhalb eines Includes verwendet, wird das Verzeichnis der eingebundenen Datei zurückgegeben. Dies entspricht dem Verhalten von dirname(__FILE__). Der Verzeichnisname hat keinen beendenden Schrägstrich, sofern es sich nicht um das Rootverzeichnis handelt.

opendir — Öffnet ein Verzeichnis-Handle 
opendir(string $directory, ?resource $context = null): resource|false

readdir — Liest einen Eintrag aus einem Verzeichnis-Handle
readdir(?resource $dir_handle = null): string|false
*/
echo __FILE__;
echo '<br />';
echo __DIR__;
echo '<br />';
echo __LINE__;
echo '<br />';
echo dirname(__FILE__);
echo '<br />';

$ordner = opendir(__DIR__.'/images');

#alle Dateien auslesen
$filename1 = readdir($ordner);
print_r($filename1);
echo '<br />';
$filename2 = readdir($ordner);
print_r($filename2);
echo '<br />';
$filename3 = readdir($ordner);
print_r($filename3);
echo '<br />';
$filename4 = readdir($ordner);
print_r($filename4);
echo '<br />';
$filename5 = readdir($ordner);
print_r($filename5);
echo '<br />';
$filename6 = readdir($ordner);
var_dump($filename6);
?>
<!--##############################################-->
<h2>Ordner einlesen (Alle Dateien, die im Ordner drin sind - keine . und ..)</h2>
<?php
$handle = opendir(__DIR__.'/images');

while( ($filename = readdir($handle)) !== false) {
	if($filename === '.' || $filename === '..') continue;
	echo '<pre>';
		print_r($filename);
	echo '</pre>';
	
	#manchmal werden versteckte Dateien erzeugt z.B. von Mac
	#dann könnte man die Abfrage auch so schreiben
	#str_starts_with() geht ab php 8
	#if(str_starts_with($filename, '.')) continue;
	
	#oder str_ends_with() -> geht nur ab php 8
	#if(!str_ends_with($filename, '.jpg')) continue;
	
	#lieber außerhalb schreiben (Trennung zwischen Schleife und Ausgabe)
	#echo '<img src="images/'.$filename.'" />';
}
?>
<!--###########################################-->
<h2>Ordner einlesen (Alle Dateien - ohne . und ..)</h2>
<?php
#Unterricht\tag08/images
$handle = opendir(__DIR__.'/images');
$filenames = [];
while( ($filename = readdir($handle)) !== false) {
	if($filename === '.' || $filename === '..') continue;
	$filenames[] = $filename;
}
#closedir — Schließt ein Verzeichnis-Handle
# closedir(?resource $dir_handle = null): void
#Schließt den in dir_handle angegebenen Verzeichnis-Stream. 
#Der Stream muss zuvor mittels opendir() geöffnet worden sein. 
closedir($handle);
var_dump($filenames);
?>
<!--###########################################-->
<h2>Bilder anzeigen (als HTML-img)</h2>
<div class="row">
<?php foreach($filenames AS $datei):?>
	<img src="images/<?=$datei?>" class="img-fluid img-thumbnail" style="width:200px" />
<?php endforeach;?>
</div>
<!--##############################################-->
</main>
<footer class="row border-top">
	<div class="col-md-6">&copy; by design</div>
	<div class="col-md-6">TERMS AND CONDITIONS</div>
</footer>
</div>
</body>
</html>
