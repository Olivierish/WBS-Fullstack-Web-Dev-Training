<?php

session_start();

require_once dirname(__DIR__,2).'/inc/db_connect.php';
require_once  dirname(__DIR__,2).'/inc/functions.php'; 

if(!empty($_POST)) {
	$name = '';
	if(isset($_POST['name'])) $name = (string) $_POST['name'];
	$mail = '';
	if(isset($_POST['mail'])) $mail = (string) $_POST['mail'];
	$pwd = '';
	if(isset($_POST['pwd'])) $pwd = (string) $_POST['pwd'];
	#---------------------------------
	if(!empty($name) && !empty($mail) && !empty($pwd)) {
		$stmt = $db->prepare('SELECT `email` FROM `users` WHERE `email` = :mail');
		$stmt->bindValue(':mail', $mail);
		$stmt->execute();
		$result = $stmt->fetch();
		#------------------
		if(!empty($result['email'])) {
			$_SESSION['msg'] = 'E-Mail existiert schon!';
		} 
		else {
			$stmt = $db->prepare('INSERT INTO users (`name`,`email`,`password`)
											VALUES(:name, :mail, :pwd)');
			$stmt->bindValue('name', $name);
			$stmt->bindValue('mail', $mail);
			$stmt->bindValue('pwd', password_hash($pwd, PASSWORD_DEFAULT));
			$stmt->execute();
			$_SESSION['msg'] = "Eintrag wurde eingefügt\nSie können sich einloggen";
		}
		#------------------
	}else {
		$_SESSION['msg'] = 'Pflichtfelder dürfen nicht leer sein';
	}
	#---------------------------------
}

redirect('../../index.php?page=register');