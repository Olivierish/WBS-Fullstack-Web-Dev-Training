<?php
session_start();

unset($_SESSION['name']);
unset($_SESSION['id']);
unset($_SESSION['login']);

$_SESSION['msg'] = 'Du bist abgemeldet!'; 
header('Location: ../../index.php');