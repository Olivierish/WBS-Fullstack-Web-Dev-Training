<!DOCTYPE html>
<html lang="de">
<head>
	<meta charset="utf-8" />
	<title>myBlog <?php pageTitle();?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link  rel="stylesheet" href="../bootstrap/css/bootstrap.css" />
	<link  rel="stylesheet" href="./css/styles.css" />
</head>
<body class="bg-secondary">
<div class="container bg-light">
<header class="row" id="header">
<div class="col-12 bg-danger bg-opacity-75 text-light">
	<h1 class="display-2 text-center">PHP -  MYSQL</h1>
</div>
<div class="col-12 bg-dark">
	<nav class="navbar navbar-expand navbar-dark">
		<ul class="navbar-nav">
			<li class="nav-item">
				<a href="index.php" class="nav-link <?php echo empty($page) ? 'current' : ''; ?>">Home</a>   
			</li>
			<li class="nav-item">
				<a href="index.php?page=about" class="nav-link <?= ($page === 'about') ? 'current' : ''; ?>">About</a>
			</li>
			<li class="nav-item">
				<a href="index.php?page=post" class="nav-link <?= ($page === 'post' || $page === 'post_detail') ? 'current' : ''; ?>">Post</a>
			</li>
			<?php if(!isset($_SESSION['id']) && !isset($_SESSION['login'])):?>
			<li class="nav-item">
				<a href="index.php?page=register" class="nav-link <?= ($page === 'register') ? 'current' : ''; ?>">Registrierung</a>
			</li>
			<li class="nav-item">
				<a href="index.php?page=login" class="nav-link <?= ($page === 'login') ? 'current' : ''; ?>">Login</a>
			</li>
			<?php else:?>
			<li class="nav-item">
				<a href="index.php?page=profil" class="nav-link <?= ($page === 'profil') ? 'current' : ''; ?>">Profil</a>
			</li>
			<?php endif;?>
			<li class="nav-item">
				<a href="index.php?page=kontakt" class="nav-link <?= ($page === 'kontakt') ? 'current' : ''; ?>">Kontakt</a> 
			</li>
		</ul>
	</nav>
</div>
<?php if(isset($_SESSION['id']) && isset($_SESSION['login'])):?>
<div class="bg-secondary bg-opacity-25 col-12 p-2">
	<h3>Hallo <?= $_SESSION['name']?></h3>
	<a href="auth/user/logout.php" class="btn btn-sm btn-outline-danger fw-bold">Logout</a>
</div>
<?php endif;?>
<!--++++++++++++++++++++++++++++++++-->
</header>
<main class="row">
<?php if(isset($_SESSION['msg'])): ?>
<div class="col-12 p-2">
	<p class="alert alert-primary"><?= nl2br($_SESSION['msg']) ?>
</div>
<?php endif;?>
