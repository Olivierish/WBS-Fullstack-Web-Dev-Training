<div class="col-12 p-2">
<form action="auth/user/insert.php" method="POST" class="rounded-1 p-2 bg-success bg-opacity-25">
<div class="p-1">
	<input type="text" name="name" class="form-control my-1" placeholder="Name eingeben..."	value = "" />
	<input type="text" name="mail" class="form-control my-1" placeholder="E-Mail eingeben..."	value = "" />
	<input type="text" name="pwd" class="form-control my-1" placeholder="Passwort eingeben..."	value = "" />
</div>
<div class="my-1 text-center">
	<input type="submit" value="mich anmelden" class="btn btn-success fw-bold" />
	<input type="reset" value="Löschen"  class="btn btn-danger fw-bold" />
</div>
</form>
</div>
