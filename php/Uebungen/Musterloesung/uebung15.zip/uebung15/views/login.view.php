<div class="col-12 p-2">
<form action="auth/user/login.php" method="POST" class="rounded-1 p-2 bg-primary bg-opacity-25">
<div class="p-1">
	<input type="text" name="mail" class="form-control my-1" placeholder="E-Mail eingeben..."	value = "" />
	<input type="password" name="pwd" class="form-control my-1" placeholder="Passwort eingeben..."	value = "" />
	<input type="hidden" name="csrf_token" class="form-control my-1" 	value = "<?= csrf_token()?>" />
</div>
<div class="my-1 text-center">
	<input type="submit" value="login" class="btn btn-success fw-bold" />
	<input type="reset" value="clear"  class="btn btn-danger fw-bold" />
</div>
</form>
</div>