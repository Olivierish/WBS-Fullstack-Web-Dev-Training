<?php

$stmt = $db->prepare('SELECT * FROM `users` WHERE `id` = :id');
$stmt->bindValue(':id', $_SESSION['id']);
$stmt->execute();
$result = $stmt->fetch();
?>
<div class="col-12 p-2">

<div class="card bg-primary m-2 text-center bg-opacity-25">
  <h2 class="card-header"><?= e($result['name'])?></h2>
  <div class="card-body">
    <p><?= e($result['ueber_mich'])?></p>

    <p>
      <a href="#" class="btn btn-warning fw-bold">Profil bearbeiten</a>
      <a href="#" class="btn btn-danger fw-bold">Profil löschen</a>
    </p>
  </div>
  <div class="card-footer">angemeldet seit: <?= formatiereDatum($result['created_at'])?></div>
</div>

</div>