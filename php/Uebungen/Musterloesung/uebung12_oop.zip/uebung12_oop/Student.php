<?php

class Student
{
	private string $firstname = '';
	private string $lastname = '';
	private float $age = 0;
	private string $email = '';
	private string $seminar = 'PHP - Grundlagen';
	private string $city = '';
	private float $preis = 300;
	
	public function __construct(string $vorname, string $nachname, float $alter, string $mail, string $ort) {
		$this->firstname = $vorname;
		$this->lastname = $nachname;
		$this->age = $alter;
		$this->email = $mail;
		$this->city = $ort;
	
		$this->ausgabe();
	}
	
	private function getLastname() {
		return strtoupper($this->lastname);
	}
	public function setLastname($value) {
		$this->lastname = $value;
	}
	
	private function getFirstname() {
		return strtoupper($this->firstname);
	}
	public function settFirstname($value) {
		$this->firstname = $value;
	}
	
	private function getAge() {
		return $this->age;
	}
	public function setAge($value) {
		$this->age = $value;
	}
	
	private function getEmail() {
		return $this->email;
	}
	public function setEmail($value) {
		$this->email = $value;
	}
	
	private function getSeminar() {
		return strtoupper($this->seminar);
	}
	public function setSeminar($value) {
		$this->seminar = $value;
	}
	
	private function getPreis() {
		if($this->getAge() < 25) {
			$this->preis -= 50; 
		}
		return $this->preis;
	}
	/*
	public function setPreis($value) {
		$this->preis = $value;
	}
	*/
	private function getCity() {
		return strtoupper($this->city);
	}
	public function setCity($value) {
		$this->city = $value;
	}
	
	
	
	private function ausgabe() {
		echo '<p><br /><b>Vielen Dank für Ihre Anmeldung: </b>
							<hr />
							Nachname: ' . $this->getLastname() . '<br />
							Vorname: ' . $this->getFirstname() . '<br />
							E-Mail: ' . $this->getEmail() . '<br />
							Wohnort: ' . $this->getCity() . '<br />
							Alter: ' . $this->getAge() . 'j.<br />
							Seminar: ' . $this->getSeminar() . '<br />
							Preis: ' . $this->getPreis() . '€<br />';
	}
}

#string $vorname, string $nachname, float $alter, string $mail, string, string $ort
$student1 = new Student('Anna','Gold',20,'anna@anna.de','Hamburg');
$student2 = new Student('Max','Mustermann',32,'max@max.de','Paris');
$student3 = new Student('Tom','Jerry',23,'tom@tom.de','Sylt');
$student4 = new Student('Hugo','Boss',27,'hugo@hugo.de','Mallorca');