<?php

class Car
{
	private int $ps = 0;
	private string $farbe = '';
	private string $marke = '';
	private float $verbrauch = 0;
	private string $kraftstoff = '';
	private float $tank = 0;
	private int $erstzulassung = 0;
	private float $preis = 0;
	private float $rabatt = 10;
	
	public function __construct(string $m, string $colour, float $p, float $t, string $k, float $v, int $erst, float $preis) {
		$this->marke = $m;
		$this->farbe = $colour;
		$this->ps = $p;
		$this->kraftstoff = $k;
		$this->tank = $t;
		$this->verbrauch = $v;
		$this->erstzulassung = $erst;
		$this->preis = $preis;
		
		$this->ausgabe();
	}
	
	private function getPs() {
		return $this->ps;
	}
	public function setPs($value) {
		$this->ps = $value;
	}
	
	private function getFarbe() {
		return strtoupper($this->farbe);
	}
	public function setFarbe($value) {
		$this->farbe = $value;
	}
	
	private function getMarke() {
		return strtoupper($this->marke);
	}
	public function setMarke($value) {
		$this->marke = $value;
	}
	
	private function getKraftstoff() {
		return strtoupper($this->kraftstoff);
	}
	public function setKraftstoff($value) {
		$this->kraftstoff = $value;
	}
	
	private function getTank() {
		return $this->tank;
	}
	public function setTank($value) {
		$this->tank = $value;
	}
	
	private function getVerbrauch() {
		return $this->verbrauch;
	}
	public function setVerbrauch($value) {
		$this->verbrauch = $value;
	}

	private function getErstzulassung() {
		return $this->erstzulassung;
	}
	public function setErstzulassung($value) {
		$this->erstzulassung = $value;
	}
	
	private function getPreis() {
		return $this->preis;
	}
	public function setPreis($value) {
		$this->preis = $value;
	}
	
	# 80 x 100 / 8
	# l x 100 / (d l)
	private function reichweite() {
		 return $this->getTank() * 	100 / $this->getVerbrauch();	
	}
	private function rabattRechner() {
		#virtuelle Attribute
		$rabattPreis =  $this->getPreis() * 10 / 100;
		return $rabattPreis;
	}
	
	private function neuerPreis() {
		return $this->getPreis() - $this->rabattRechner();
	}
	private function ausgabe() {
		echo '<p><br /><b>Daten des Autos: </b>
							<hr />
							Marke: ' . $this->getMarke() . '<br />
							Farbe: ' . $this->getFarbe() . '<br />
							Erstzulassung: ' . $this->getErstzulassung() . '<br />
							Preis: ' . $this->getPreis() . '<br />';
							
							if($this->getErstzulassung() < 2000):
								echo '<b>Rabatt: ' . $this->rabatt . '%<br />
										 Preisnachlass:' . $this->rabattRechner() . '<br />
										 Neuer Preis: ' . $this->neuerPreis() . '</b><br />';
							endif;
							
		echo			'PS: ' . $this->ps .'ps <br />
							Durchschnittsverbrauch: ' . $this->getVerbrauch() .' liter pro km <br />
							Tankvolumen: '. $this->tank . ' liter<br />
							Kraftstoffart: ' . $this->getKraftstoff() .' <br />
							Reichweite: ' . $this->reichweite().' km'.
					'</p>';
	}
}

#string $m, string $colour, float $p, float $t, string $k, float $v, int $erst, float $preis
$car1 = new Car('vw', 'rot', 80, 50, 'benzin',5, 1999, 10000);
$car2 = new Car('audi', 'blau', 200, 100, 'diesel',10, 2015, 30000);
$car3 = new Car('bmw', 'blau', 300, 100, 'benzin',20, 2020, 45000);
