<?php
$personen = array(
    array(
        'name' => 'Marie LUISE Kaschnitz',
        'wohnort' => 'Paris',
        'geboren' => '2000/12/31',
        'kurzeInfo' => 'Überall dieselbe alte Leier. Das Layout ist fertig, der Text lässt auf sich warten.'
    ),
    array(
        'name' => 'matthiAS CLaudIUs',
        'wohnort' => 'Bangkok',
        'geboren' => '1995/06/23',
        'kurzeInfo' => 'Überall dieselbe alte Leier. Das Layout ist fertig, der Text lässt auf sich warten.'
    ),
    array(
        'name' => 'GertRUD KOLMAR',
        'wohnort' => 'St. Peter Ording',
        'geboren' => '1998/11/23',
        'kurzeInfo' => 'Überall dieselbe alte Leier. Das Layout ist fertig, der Text lässt auf sich warten.'
    ),
    array(
        'name' => 'JosePH VON Eichendorff',
        'wohnort' => 'Algarve',
        'geboren' => '1987/07/01',
        'kurzeInfo' => 'Überall dieselbe alte Leier. Das Layout ist fertig, der Text lässt auf sich warten.'
    )
);
?>