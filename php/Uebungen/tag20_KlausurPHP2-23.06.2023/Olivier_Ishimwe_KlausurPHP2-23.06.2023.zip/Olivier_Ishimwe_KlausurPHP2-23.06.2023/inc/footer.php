
</main>
<footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top">
    <p class="col-md-4 mb-0 text-secondary">© 2023 Olivieris</p>

    <a href="#" class="col-md-4 d-flex align-items-center justify-content-center mb-3 mb-md-0 me-md-auto text-decoration-none">
      php . olivieris . Bausteinprüfung . 23.06.2023
    </a>

    <ul class="nav col-md-4 justify-content-end">
      <li class="nav-item"><a href="views/impressum.view.php" class="nav-link px-2 text-secondary">Impressum</a></li>
    </ul>

  </footer>
</div>
<script src="js/master.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
</body>
</html> 