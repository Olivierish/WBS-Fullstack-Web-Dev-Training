
const msgElt = document.getElementById("msg");

const hideMessage = () => {
  msgElt.style.display = "none";
};

setTimeout(hideMessage, 3000);
