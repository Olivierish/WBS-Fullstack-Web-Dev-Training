<div class="row">
  <h2 class="h2 text-primary mt-2">Impressum</h2>
  <p>
  Die auf dieser Website bereitgestellten Informationen und Daten dienen ausschließlich zu Bildungs- und Forschungszwecken. Die Richtigkeit und Vollständigkeit der auf dieser Website bereitgestellten Informationen und Daten kann nicht garantiert werden. Alle Handlungen, die aufgrund der auf dieser Website bereitgestellten Informationen und Daten vorgenommen werden, erfolgen auf eigene Gefahr. Diese Website übernimmt keine Haftung für etwaige Verluste oder Schäden, die aus der Nutzung der auf dieser Website bereitgestellten Informationen und Daten entstehen können.
    </p>
    <h3 class="h3 text-secondary mt-2">Kontakt</h2>
    <pre>
        Email: oli@olivieris.de
        Phone: +49 123456789
        Address: Musterstrasse 10, 81000, Nürnberg.
</pre>

    <h3 class="h3 text-secondary mt-2">Datenschutzrichtlinie</h2>
    <p>Diese Website verpflichtet sich, die Privatsphäre ihrer Benutzer zu schützen. Wir sammeln keine personenbezogenen Informationen von unseren Benutzern, es sei denn, sie werden freiwillig bereitgestellt. Alle uns zur Verfügung gestellten Informationen werden vertraulich behandelt und nicht an Dritte weitergegeben.</p>

    <h3 class="h3 text-secondary mt-2">Nutzungsbedingungen</h2>
    <p>
    Diese Website wird ausschließlich zu Bildungs- und Forschungszwecken zur Verfügung gestellt. Die auf dieser Website bereitgestellten Informationen und Daten sind nicht garantiert, aktuell und korrekt zu sein. Wir übernehmen keine Verantwortung für Verluste oder Schäden, die aus der Nutzung dieser Website entstehen.
    </p>

    <div>
		<a class="btn btn-primary btn-lg" href="index.php" role="button">zurück</a>
    </div>
</div>
