<?php

/** 
 * DB variables for XAMPP.
 * 
 * @author https://sourceforge.net/projects/lwt/ LWT Project
 * @since  1.0.3
 */

$server = "localhost";
$userid = "root";
$passwd = "";
$dbname = "learning-with-texts";

?>
