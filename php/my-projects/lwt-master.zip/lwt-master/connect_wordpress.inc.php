<?php

/**
 * \file
 * \brief DB variables when LWT is integrated with WordPress.
 * 
 * @author https://sourceforge.net/projects/lwt/ LWT Project
 * @since  1.5.5
 */
  
// database server
// $server = "";

// database userid
// $userid = "";

// database password
// $passwd = "";

// database name
// $dbname = "";

require_once 'inc/wp_logincheck.php' ;   

?>
