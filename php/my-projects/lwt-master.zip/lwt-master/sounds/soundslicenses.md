<div>
<!--
\file 
\brief Sounds description for the Default_Mod theme.
-->
</div>

# Sound Licenses

* ``success.mp3`` 
  * Author: MattLeschuck
  * License: [Simplified Pixabay License](https://pixabay.com/service/license/)
  * Source: https://pixabay.com/sound-effects/success-bell-6776/ 
  * Use: when succeding in a word test

* ``failure.mp3``
  * Author: [ProdWizz](https://pixabay.com/users/prodwizz-19197905/)
  * License: [Simplified Pixabay License](https://pixabay.com/service/license/)
  * Source: https://pixabay.com/sound-effects/kurze-synth-floten-melodie-loop-9675/
  * Use: when failing on a word test
  * It is a shortened version
