# Setup for Tablets

> **Note**: this is a deprecated feature, LWT should work with your tablet out of the box!

If you want to use LWT on a tablet: that's possible (even the audio player works!).

In "Settings/Preferences", set the "Frame Set Display Mode" to "Auto" or "Force Mobile". On other mobile devices, you may also try "Force Non-Mobile" if you are unhappy with the results, try to reduce the length of your texts to reduce scrolling.

It's also a good idea to install and run LWT at a web hoster. So you can access LWT easily if you are often on the go.

I hope you will enjoy using LWT on a tablet although creating new terms and copy & paste can be a bit tedious.
