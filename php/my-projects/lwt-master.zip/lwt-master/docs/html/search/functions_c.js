var searchData=
[
  ['quickmenu_0',['quickMenu',['../kernel__utility_8php.html#a968ebfd30d4d63e55078ab5668e991ff',1,'kernel_utility.php']]]
];
