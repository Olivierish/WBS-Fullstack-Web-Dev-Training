var searchData=
[
  ['edit_5flanguages_2ephp_0',['edit_languages.php',['../edit__languages_8php.html',1,'']]],
  ['edit_5fmword_2ephp_1',['edit_mword.php',['../edit__mword_8php.html',1,'']]],
  ['edit_5ftexts_2ephp_2',['edit_texts.php',['../edit__texts_8php.html',1,'']]],
  ['edit_5ftword_2ephp_3',['edit_tword.php',['../edit__tword_8php.html',1,'']]],
  ['edit_5fword_2ephp_4',['edit_word.php',['../edit__word_8php.html',1,'']]]
];
