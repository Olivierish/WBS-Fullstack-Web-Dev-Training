var searchData=
[
  ['savesetting_0',['SaveSetting',['../namespace_save_setting.html',1,'']]]
];
