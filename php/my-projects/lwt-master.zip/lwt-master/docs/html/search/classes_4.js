var searchData=
[
  ['term_0',['Term',['../class_term.html',1,'']]]
];
