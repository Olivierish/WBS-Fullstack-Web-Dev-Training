var searchData=
[
  ['validatelang_0',['validateLang',['../database__connect_8php.html#a02d40918dc384387272eb42f065925c6',1,'database_connect.php']]],
  ['validatetext_1',['validateText',['../database__connect_8php.html#a79bc2cd98f888142e3e9ccc0c0b5f7c0',1,'database_connect.php']]]
];
