var searchData=
[
  ['select_5flang_5fpair_2ephp_0',['select_lang_pair.php',['../select__lang__pair_8php.html',1,'']]],
  ['server_5fdata_2ephp_1',['server_data.php',['../server__data_8php.html',1,'']]],
  ['session_5futility_2ephp_2',['session_utility.php',['../session__utility_8php.html',1,'']]],
  ['set_5ftest_5fstatus_2ephp_3',['set_test_status.php',['../set__test__status_8php.html',1,'']]],
  ['set_5ftext_5fmode_2ephp_4',['set_text_mode.php',['../set__text__mode_8php.html',1,'']]],
  ['set_5fword_5fstatus_2ephp_5',['set_word_status.php',['../set__word__status_8php.html',1,'']]],
  ['settings_2ephp_6',['settings.php',['../inc_2settings_8php.html',1,'']]],
  ['simterms_2ephp_7',['simterms.php',['../simterms_8php.html',1,'']]],
  ['start_2ephp_8',['start.php',['../start_8php.html',1,'']]],
  ['start_5fsession_2ephp_9',['start_session.php',['../start__session_8php.html',1,'']]]
];
