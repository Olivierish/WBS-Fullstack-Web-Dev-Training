var searchData=
[
  ['unset_5fsettings_0',['unset_settings',['../namespace_save_setting.html#a92cf4cf916a6da3ca22a5fb0eadb0552',1,'SaveSetting']]],
  ['update_5fdatabase_1',['update_database',['../database__connect_8php.html#aee77a1d03a5cce20d89d97a88d587dd6',1,'database_connect.php']]],
  ['update_5fdefault_5fvalues_2',['update_default_values',['../database__connect_8php.html#a31fb489225a5a5c071b6fb7d2ddcbea1',1,'database_connect.php']]],
  ['update_5fjapanese_5fword_5fcount_3',['update_japanese_word_count',['../database__connect_8php.html#a280dddf6818f5a62d97ce50015e76504',1,'database_connect.php']]],
  ['update_5fword_5fstatus_4',['update_word_status',['../ajax__chg__term__status_8php.html#aeb875bfdb5f0c40515cd8e0d3a3490c7',1,'ajax_chg_term_status.php']]],
  ['upload_5fwords_5fdisplay_5',['upload_words_display',['../upload__words_8php.html#a81ec76ce1786cd85859763198f443ab3',1,'upload_words.php']]],
  ['upload_5fwords_5fimport_6',['upload_words_import',['../upload__words_8php.html#a49aa13623696cfd6b1541544c64a459f',1,'upload_words.php']]],
  ['upload_5fwords_5fimport_5ftags_7',['upload_words_import_tags',['../upload__words_8php.html#a24232747e3b16cc87c51434342d00c24',1,'upload_words.php']]],
  ['upload_5fwords_5fimport_5fterms_8',['upload_words_import_terms',['../upload__words_8php.html#a2e235fca427e76a3e70f2aa2ed156652',1,'upload_words.php']]],
  ['url_5fbase_9',['url_base',['../kernel__utility_8php.html#aaf8aa013b97e5bcf60c560fd6cad05fe',1,'kernel_utility.php']]]
];
