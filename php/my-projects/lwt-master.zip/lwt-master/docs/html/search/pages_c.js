var searchData=
[
  ['restrictions_0',['Restrictions',['../md_docs_restrictions.html',1,'']]]
];
