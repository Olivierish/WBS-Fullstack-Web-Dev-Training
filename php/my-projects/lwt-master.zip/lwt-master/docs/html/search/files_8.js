var searchData=
[
  ['langdefs_2ephp_0',['langdefs.php',['../langdefs_8php.html',1,'']]],
  ['language_2ephp_1',['Language.php',['../_language_8php.html',1,'']]],
  ['long_5ftext_5fimport_2ephp_2',['long_text_import.php',['../long__text__import_8php.html',1,'']]]
];
