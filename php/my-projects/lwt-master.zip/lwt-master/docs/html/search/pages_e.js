var searchData=
[
  ['term_20scores_0',['Term Scores',['../md_docs_termscores.html',1,'']]],
  ['third_20party_20licenses_1',['Third Party Licenses',['../md_docs_thirdpartylicenses.html',1,'']]]
];
