var searchData=
[
  ['print_5fimpr_5ftext_2ephp_0',['print_impr_text.php',['../print__impr__text_8php.html',1,'']]]
];
