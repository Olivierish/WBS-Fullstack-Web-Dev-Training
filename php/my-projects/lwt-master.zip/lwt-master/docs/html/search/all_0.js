var searchData=
[
  ['_24debug_0',['$debug',['../inc_2settings_8php.html#a013c4d66c94ae519412159b9e54522c0',1,'settings.php']]],
  ['_24dsplerrors_1',['$dsplerrors',['../inc_2settings_8php.html#aa693597284238e0824fd36c1a5976ab4',1,'settings.php']]],
  ['_24dspltime_2',['$dspltime',['../inc_2settings_8php.html#a9604729e70d98ec7f7656756c14823a5',1,'settings.php']]]
];
