var searchData=
[
  ['backup_5frestore_2ephp_0',['backup_restore.php',['../backup__restore_8php.html',1,'']]],
  ['bulk_5ftranslate_5fwords_2ephp_1',['bulk_translate_words.php',['../bulk__translate__words_8php.html',1,'']]]
];
