var searchData=
[
  ['setup_20for_20tablets_0',['Setup for Tablets',['../md_docs_ipad.html',1,'']]],
  ['soundslicenses_1',['soundslicenses',['../md_sounds_soundslicenses.html',1,'(Global Namespace)'],['../md_themes__night__mode_soundslicenses.html',1,'(Global Namespace)']]]
];
