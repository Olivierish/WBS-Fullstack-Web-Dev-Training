var searchData=
[
  ['language_5fid_5ffrom_5fcode_0',['language_id_from_code',['../text__to__speech__settings_8php.html#a31b8e8b569f8f75610b3f7a70b330092',1,'text_to_speech_settings.php']]],
  ['letterpairs_1',['letterPairs',['../simterms_8php.html#a3e3a7c7054ca98a3eb429743b15d534d',1,'simterms.php']]],
  ['load_5flanguage_2',['load_language',['../edit__languages_8php.html#a2f709d8f0ae540267a6c520c8df76072',1,'edit_languages.php']]],
  ['long_5ftext_5fcheck_3',['long_text_check',['../long__text__import_8php.html#aa3af65e7bfae8fce2d0dfebf61556338',1,'long_text_import.php']]],
  ['long_5ftext_5fdisplay_4',['long_text_display',['../long__text__import_8php.html#ad448e989e470b7fca9b9891e56d1438e',1,'long_text_import.php']]],
  ['long_5ftext_5fdo_5fpage_5',['long_text_do_page',['../long__text__import_8php.html#a61c59c6bcfdb07a2c0b218dc47f26c36',1,'long_text_import.php']]],
  ['long_5ftext_5fsave_6',['long_text_save',['../long__text__import_8php.html#a40bc78ee69a9da7ada1ae6f33ec1696b',1,'long_text_import.php']]],
  ['lowercase_5fterm_5fnot_5fequal_7',['lowercase_term_not_equal',['../edit__word_8php.html#a33dc93ccc75abf0d96a2f9ad51258c5f',1,'edit_word.php']]],
  ['lwttablecheck_8',['LWTTableCheck',['../database__connect_8php.html#aa238ca54e7fb04ab59f8e19e90b8d64f',1,'database_connect.php']]]
];
