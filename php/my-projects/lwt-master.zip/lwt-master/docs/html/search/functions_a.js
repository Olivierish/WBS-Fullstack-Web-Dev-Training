var searchData=
[
  ['optimizedb_0',['optimizedb',['../database__connect_8php.html#a8ac89d832d3a95c00b38bad4b46bbe19',1,'database_connect.php']]]
];
