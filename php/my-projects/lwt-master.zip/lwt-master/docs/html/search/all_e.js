var searchData=
[
  ['optimizedb_0',['optimizedb',['../database__connect_8php.html#a8ac89d832d3a95c00b38bad4b46bbe19',1,'database_connect.php']]],
  ['optional_20post_2dinstallation_20steps_1',['Optional Post-Installation Steps',['../md_docs_postinstall.html',1,'']]]
];
