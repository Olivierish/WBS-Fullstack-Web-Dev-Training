var searchData=
[
  ['refreshtext_0',['refreshText',['../session__utility_8php.html#aee9ee100264b8ab008c86fe82c0cbf37',1,'session_utility.php']]],
  ['regeneratesingletheme_1',['regenerateSingleTheme',['../minifier_8php.html#a9f4db3b660cd73adfc45c38b3d201430',1,'minifier.php']]],
  ['regeneratethemes_2',['regenerateThemes',['../minifier_8php.html#a9cb255dd747fe942370e452da3bab032',1,'minifier.php']]],
  ['remove_5fspaces_3',['remove_spaces',['../kernel__utility_8php.html#aa35690eeba61cd1173255d841176a7b2',1,'kernel_utility.php']]],
  ['reparse_5fall_5ftexts_4',['reparse_all_texts',['../database__connect_8php.html#ac536fa1c9af67239c031c2fbebd2ddef',1,'database_connect.php']]],
  ['repl_5ftab_5fnl_5',['repl_tab_nl',['../session__utility_8php.html#a90041847911a29c74820f432a2ed1663',1,'session_utility.php']]],
  ['restore_5ffile_6',['restore_file',['../session__utility_8php.html#afc54300f39eca3740804099bb93fd9eb',1,'session_utility.php']]],
  ['restrictions_7',['Restrictions',['../md_docs_restrictions.html',1,'']]],
  ['runsql_8',['runsql',['../database__connect_8php.html#acba5ba1657b74c879fc17dd6f13c6bce',1,'database_connect.php']]]
];
