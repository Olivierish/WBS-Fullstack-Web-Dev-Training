var searchData=
[
  ['add_5fnew_5fterm_5ftransl_0',['add_new_term_transl',['../ajax__add__term__transl_8php.html#ae95444187deb18ec23aaae657a69bfcb',1,'ajax_add_term_transl.php']]],
  ['adjust_5fautoincr_1',['adjust_autoincr',['../database__connect_8php.html#a553441f4fbb4aef5ad113142d5998bae',1,'database_connect.php']]],
  ['all_5fwords_5fwellknown_5fcontent_2',['all_words_wellknown_content',['../all__words__wellknown_8php.html#a892bafeaaaff5f1fff8f32be0dbbbec8',1,'all_words_wellknown.php']]],
  ['all_5fwords_5fwellknown_5fcount_5fterms_3',['all_words_wellknown_count_terms',['../all__words__wellknown_8php.html#ad3fdf58cfe414a0577508e71860cd5f3',1,'all_words_wellknown.php']]],
  ['all_5fwords_5fwellknown_5ffull_4',['all_words_wellknown_full',['../all__words__wellknown_8php.html#a31c886b54bd5eacd9f1fa69b68ea3e29',1,'all_words_wellknown.php']]],
  ['all_5fwords_5fwellknown_5fget_5fwords_5',['all_words_wellknown_get_words',['../all__words__wellknown_8php.html#aa02001b2fcd137dd55e2a686bb33aa0d',1,'all_words_wellknown.php']]],
  ['all_5fwords_5fwellknown_5fjavascript_6',['all_words_wellknown_javascript',['../all__words__wellknown_8php.html#a6defdb6224f9f84b18e55be6193c9f1b',1,'all_words_wellknown.php']]],
  ['all_5fwords_5fwellknown_5fmain_5floop_7',['all_words_wellknown_main_loop',['../all__words__wellknown_8php.html#aa7aecd66a19c9867d139fc39e0a6d9af',1,'all_words_wellknown.php']]],
  ['all_5fwords_5fwellknown_5fprocess_5fword_8',['all_words_wellknown_process_word',['../all__words__wellknown_8php.html#a6300e9558f4e64dfbe77dde0bf02eca5',1,'all_words_wellknown.php']]],
  ['anki_5fexport_9',['anki_export',['../session__utility_8php.html#ab95fac371d3020bb609b29da5c2b8b99',1,'session_utility.php']]],
  ['annotation_5fto_5fjson_10',['annotation_to_json',['../kernel__utility_8php.html#ad7032b1f81635b990de6f210394d26b9',1,'kernel_utility.php']]]
];
