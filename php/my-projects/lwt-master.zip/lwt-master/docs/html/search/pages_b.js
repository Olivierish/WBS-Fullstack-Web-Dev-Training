var searchData=
[
  ['questions_20and_20answers_0',['Questions and Answers',['../md_docs_faq.html',1,'']]]
];
