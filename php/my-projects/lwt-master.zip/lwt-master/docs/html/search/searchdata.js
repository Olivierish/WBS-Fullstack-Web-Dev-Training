var indexSectionsWithContent =
{
  0: "$abcdefghiklmnopqrstuvw",
  1: "gklmt",
  2: "ls",
  3: "abcdegiklmpstuw",
  4: "acdefgilmnopqrstuvw",
  5: "$",
  6: "acdfhiklnopqrstw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Pages"
};

