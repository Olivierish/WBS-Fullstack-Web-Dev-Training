var searchData=
[
  ['term_2ephp_0',['Term.php',['../_term_8php.html',1,'']]],
  ['text_5ffrom_5fyt_2ephp_1',['text_from_yt.php',['../text__from__yt_8php.html',1,'']]],
  ['text_5fto_5fspeech_5fsettings_2ephp_2',['text_to_speech_settings.php',['../text__to__speech__settings_8php.html',1,'']]],
  ['trans_2ephp_3',['trans.php',['../trans_8php.html',1,'']]]
];
