var searchData=
[
  ['language_0',['Language',['../class_language.html',1,'']]]
];
