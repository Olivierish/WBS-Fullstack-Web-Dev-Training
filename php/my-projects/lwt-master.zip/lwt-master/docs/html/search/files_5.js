var searchData=
[
  ['googletranslate_2ephp_0',['GoogleTranslate.php',['../_google_translate_8php.html',1,'']]]
];
