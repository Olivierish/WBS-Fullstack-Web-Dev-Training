var searchData=
[
  ['index_2ephp_0',['index.php',['../index_8php.html',1,'']]],
  ['info_2ephp_1',['info.php',['../info_8php.html',1,'']]],
  ['insert_5fword_5fignore_2ephp_2',['insert_word_ignore.php',['../insert__word__ignore_8php.html',1,'']]],
  ['insert_5fword_5fwellknown_2ephp_3',['insert_word_wellknown.php',['../insert__word__wellknown_8php.html',1,'']]]
];
