<?php

/**
 * \file
 * \brief DB variables for EasyPHP.
 * 
 * @author https://sourceforge.net/projects/lwt/ LWT Project
 * @since  1.0.3
 */

$server = "127.0.0.1";
$userid = "root";
$passwd = "";
$dbname = "learning-with-texts";

?>
