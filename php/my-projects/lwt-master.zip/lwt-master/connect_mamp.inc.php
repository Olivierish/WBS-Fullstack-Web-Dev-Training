<?php

/**
 * \file
 * \brief DB variables for MAMP
 */

$server = "localhost:8889";
$userid = "root";
$passwd = "root";
$dbname = "learning-with-texts";

?>
