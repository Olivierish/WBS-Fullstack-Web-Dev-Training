const frame = new Frame("fit", 800, 600);
frame.on("ready", ()=>{ // ES6 Arrow Function - similar to function(){}
    zog("ready from ZIM Frame"); // logs in console (F12 - choose console)

    // often need below - so consider it part of the template
    let stage = frame.stage;
    let stageW = frame.width;
    let stageH = frame.height;
    frame.outerColor = "#555";
    frame.color = "#222";

    // REFERENCES for ZIM at http://zimjs.com
    // see http://zimjs.com/learn.html for video and code tutorials
    // see http://zimjs.com/docs.html for documentation
    // see https://www.youtube.com/watch?v=pUjHFptXspM for INTRO to ZIM
    // see https://www.youtube.com/watch?v=v7OT0YrDWiY for INTRO to CODE

    // CODE HERE
		const load = frame.loadAssets(["spaceguy.png", "spaceguy.json"], "https://d309knd7es5f10.cloudfront.net/codepen/");
		load.on("complete", ()=>{
	
			// create a background then scroll it with a Scroller (could use an image, etc.)
			// can use lots of backgrounds for parallax - see http://zimjs.com/zide/
			const background = new Tile(new Circle(10, frame.pink), 35, 10, null, 5, 5)
				.alp(.5).center();
			new Scroller({backing:background, speed:1.5, gapFix:-5}); // gapFix matches the tile spacing

			// bring in an animated spaceguy sprite - animated by Antonio Caggiano from Sheridan
			const spaceGuy = new Sprite({json:frame.asset("spaceguy.json")})
				.center().mov(-20,80)
				.run({loop:true});
			
			new Label({text:"Scroller for animated backgrounds...", color:frame.white}).alp(.5).pos(50,50,stage);
			
		}); // end assets loading
  
    // DOCS FOR ITEMS USED
    // http://zimjs.com/docs.html?item=scoller
    // http://zimjs.com/docs.html?item=tile
    // http://zimjs.com/docs.html?item=mov
    // http://zimjs.com/docs.html?item=alp
    // http://zimjs.com/docs.html?item=center
    // http://zimjs.com/docs.html?item=label
    // http://zimjs.com/docs.html?item=pos
    // http://zimjs.com/docs.html?item=frame
  
    // FOOTER
    // call remote script to make ZIM Foundation for Creative Coding icon
    createIcon(frame); 

}); // end of ready