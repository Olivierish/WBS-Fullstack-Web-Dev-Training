Die Lösungen in den Ordnern
number, string, schleife entsprechen den Aufgaben
aus der Datei, aufgaben.html

Die Lösungen in den Ordnern
tag3, tag4, entsprechen den entsprechen den Aufgaben, der Tage

Die Aufgaben der Tage sind eine Teilmenge, der Aufgaben, die 
in aufgaben.html aufgeführt sind.