import "./styles.css";
import React, { useState } from "react";
import Home from "./components/Home";
import About from "./components/About";
import Offer from "./components/Offer";

export default function App() {
  const [page, setPage] = useState("home");

  const handleNavigation = (newPage) => {
    setPage(newPage);
  };

  let pageContent;
  if (page === "about") {
    pageContent = <About />;
  } else if (page === "offer") {
    pageContent = <Offer />;
  } else {
    pageContent = <Home />;
  }

  return (
    <div className="App">
      <header>
        <nav>
          <ul>
            <li onClick={() => handleNavigation("home")}>Startseite</li>
            <li onClick={() => handleNavigation("about")}>Über mich</li>
            <li onClick={() => handleNavigation("offer")}>Meine Angebote</li>
          </ul>
        </nav>
      </header>
      <hr />
      {pageContent}
    </div>
  );
}
