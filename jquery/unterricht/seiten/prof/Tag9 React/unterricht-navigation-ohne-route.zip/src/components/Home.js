import React from "react";

function Home() {
  return (
    <div className="home">
      <h1>Das ist die die Home-Seite</h1>
      <p>Herzlich Willkommen bei dem React-Beispiel</p>
      <hr />
      <p>Hier kann üblicher Inhalt rein</p>
    </div>
  );
}

export default Home;
