import React from "react";

function About() {
  return (
    <div className="about">
      <h1>Das ist die About-Seite</h1>
      <p>Hier erfahrt ihr etwas über mich</p>
      <hr />
      <p>
        Name: <strong>Gerald Reinhardt</strong>
      </p>
      <p> Lernbegleiter bei der WBS seit 2018</p>
      <p> Aktuell im Unterricht für JavaScript Framework jQuery</p>
    </div>
  );
}

export default About;
