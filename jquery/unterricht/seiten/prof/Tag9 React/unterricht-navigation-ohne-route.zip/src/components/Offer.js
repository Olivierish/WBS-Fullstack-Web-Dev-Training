import React from "react";

function Offer() {
  return (
    <div className="offer">
      <h1 id="thema">Das ist die Offer-Seite</h1>
      <p>Hier könnt ihr lesen, was ich so bieten kann</p>
      <hr />
      <ul>
        <li>Lernbegleitung</li>
        <li>Online-Training</li>
        <li>Entwicklung/Beratung</li>
        <li class="privat">Urlaubsbegleitung</li>
        <li class="privat">Enkelbetreuung</li>
      </ul>
    </div>
  );
}

export default Offer;
