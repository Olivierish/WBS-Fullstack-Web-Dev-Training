import React from "react";

function InnerComponent() {
  return (
    <div className="inner">
      <h2> Das ist die innere Komponente</h2>
      <p> der Inhalt der inneren Komponente kann hier rein</p>
    </div>
  );
}

export default InnerComponent;
