import React from 'react';
import InnerComponent from './InnerComponent';

function OuterComponent() {
  return (
    <div className="aussen">
        <h2>Äußere Komponente</h2>
        <p>Inhalt für die äussere Komponente</p>
        <InnerComponent />
        <InnerComponent />
   
    </div>  
  )
}

export default OuterComponent;
